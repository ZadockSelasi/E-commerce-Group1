import type { Metadata } from "next"
import OrdersPageClient from "./orders-page-client"

export const metadata: Metadata = {
  title: "My Orders | ShopNow",
  description: "View and track your orders",
}

export default function OrdersPage() {
  return <OrdersPageClient />
}

