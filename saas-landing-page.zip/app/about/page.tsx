import type { Metadata } from "next"
import Image from "next/image"
import Link from "next/link"
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink } from "@/components/ui/breadcrumb"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Home, CheckCircle, Award, Users, TrendingUp } from "lucide-react"

export const metadata: Metadata = {
  title: "About Us | ShopNow",
  description: "Learn about our company, our mission, and the team behind ShopNow",
}

export default function AboutPage() {
  return (
    <div>
      {/* Hero Banner */}
      <div className="relative w-full h-[300px] md:h-[400px]">
        <Image
          src="/placeholder.svg?height=800&width=1920&text=About+Us"
          alt="About ShopNow"
          fill
          priority
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
          <div className="text-center text-white px-4">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">About ShopNow</h1>
            <p className="text-lg md:text-xl max-w-2xl mx-auto">
              Get to know our story, our mission, and the people behind our success
            </p>
          </div>
        </div>
      </div>

      <div className="container px-4 py-8 md:px-6 md:py-12">
        <Breadcrumb className="mb-8">
          <BreadcrumbItem>
            <BreadcrumbLink href="/">
              <Home className="h-4 w-4" />
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbItem>
            <BreadcrumbLink href="/about" isCurrentPage>
              About Us
            </BreadcrumbLink>
          </BreadcrumbItem>
        </Breadcrumb>

        {/* Our Story Section */}
        <section className="mb-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-4">Our Story</h2>
              <div className="space-y-4">
                <p>
                  Founded in 2015, ShopNow began with a simple mission: to create an online shopping experience that
                  combines quality, convenience, and exceptional customer service.
                </p>
                <p>
                  What started as a small operation with just 5 team members has grown into a thriving e-commerce
                  platform serving thousands of customers worldwide. Our journey has been defined by our commitment to
                  innovation and our passion for delivering products that enhance people's lives.
                </p>
                <p>
                  Today, ShopNow offers a curated selection of products across multiple categories, each chosen with our
                  customers' needs and preferences in mind. We continue to grow and evolve, but our core values remain
                  the same.
                </p>
              </div>
            </div>
            <div className="relative h-[400px] rounded-lg overflow-hidden">
              <Image
                src="/placeholder.svg?height=800&width=800&text=Our+Story"
                alt="ShopNow Story"
                fill
                className="object-cover"
              />
            </div>
          </div>
        </section>

        {/* Mission & Values Section */}
        <section className="mb-16 bg-muted rounded-lg p-8">
          <h2 className="text-3xl font-bold mb-8 text-center">Our Mission & Values</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="bg-primary/10 p-3 rounded-full mb-4">
                    <CheckCircle className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">Quality</h3>
                  <p className="text-muted-foreground">
                    We are committed to offering only the highest quality products that meet our rigorous standards.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="bg-primary/10 p-3 rounded-full mb-4">
                    <Users className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">Customer Focus</h3>
                  <p className="text-muted-foreground">
                    Our customers are at the heart of everything we do. We strive to exceed expectations in every
                    interaction.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="bg-primary/10 p-3 rounded-full mb-4">
                    <TrendingUp className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">Innovation</h3>
                  <p className="text-muted-foreground">
                    We continuously seek new ways to improve our products, services, and the overall shopping
                    experience.
                  </p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <div className="bg-primary/10 p-3 rounded-full mb-4">
                    <Award className="h-6 w-6 text-primary" />
                  </div>
                  <h3 className="text-xl font-bold mb-2">Integrity</h3>
                  <p className="text-muted-foreground">
                    We conduct our business with honesty, transparency, and respect for our customers, partners, and
                    team members.
                  </p>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        {/* Team Section */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold mb-8 text-center">Meet Our Team</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              {
                name: "Sarah Johnson",
                role: "CEO & Founder",
                image: "/placeholder.svg?height=400&width=400&text=Sarah",
              },
              { name: "Michael Chen", role: "CTO", image: "/placeholder.svg?height=400&width=400&text=Michael" },
              {
                name: "Emily Rodriguez",
                role: "Head of Operations",
                image: "/placeholder.svg?height=400&width=400&text=Emily",
              },
              {
                name: "David Kim",
                role: "Creative Director",
                image: "/placeholder.svg?height=400&width=400&text=David",
              },
            ].map((member, index) => (
              <div key={index} className="flex flex-col items-center text-center">
                <div className="relative w-40 h-40 rounded-full overflow-hidden mb-4 border dark:border-gray-700">
                  <Image
                    src={member.image || "/placeholder.svg"}
                    alt={member.name}
                    fill
                    className="object-cover dark:dark-image-filter"
                  />
                </div>
                <h3 className="text-xl font-bold">{member.name}</h3>
                <p className="text-muted-foreground">{member.role}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Milestones & Testimonials Tabs */}
        <section className="mb-16">
          <Tabs defaultValue="milestones">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="milestones">Our Milestones</TabsTrigger>
              <TabsTrigger value="testimonials">Customer Testimonials</TabsTrigger>
            </TabsList>
            <TabsContent value="milestones" className="mt-6">
              <div className="space-y-8">
                <div className="relative pl-8 pb-8 border-l-2 border-primary/30 dark:border-primary/50">
                  <div className="absolute left-[-8px] top-0 w-4 h-4 rounded-full bg-primary"></div>
                  <h3 className="text-xl font-bold">2015: The Beginning</h3>
                  <p className="text-muted-foreground mt-2">
                    ShopNow was founded with a vision to revolutionize online shopping.
                  </p>
                </div>

                <div className="relative pl-8 pb-8 border-l-2 border-primary/30 dark:border-primary/50">
                  <div className="absolute left-[-8px] top-0 w-4 h-4 rounded-full bg-primary"></div>
                  <h3 className="text-xl font-bold">2017: Expansion</h3>
                  <p className="text-muted-foreground mt-2">
                    We expanded our product range to include electronics and home goods.
                  </p>
                </div>

                <div className="relative pl-8 pb-8 border-l-2 border-primary/30 dark:border-primary/50">
                  <div className="absolute left-[-8px] top-0 w-4 h-4 rounded-full bg-primary"></div>
                  <h3 className="text-xl font-bold">2019: International Launch</h3>
                  <p className="text-muted-foreground mt-2">
                    ShopNow went global, shipping to over 50 countries worldwide.
                  </p>
                </div>

                <div className="relative pl-8">
                  <div className="absolute left-[-8px] top-0 w-4 h-4 rounded-full bg-primary"></div>
                  <h3 className="text-xl font-bold">2022: Mobile App</h3>
                  <p className="text-muted-foreground mt-2">
                    We launched our mobile app, making shopping on-the-go easier than ever.
                  </p>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="testimonials" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {[
                  {
                    name: "Alex T.",
                    location: "New York, NY",
                    text: "ShopNow has been my go-to online store for years. Their product quality and customer service are unmatched!",
                    image: "/placeholder.svg?height=100&width=100&text=Alex",
                  },
                  {
                    name: "Maria S.",
                    location: "Los Angeles, CA",
                    text: "I love how easy it is to find exactly what I'm looking for on ShopNow. The website is intuitive and the delivery is always prompt.",
                    image: "/placeholder.svg?height=100&width=100&text=Maria",
                  },
                  {
                    name: "James L.",
                    location: "Chicago, IL",
                    text: "The quality of products I've received from ShopNow has always exceeded my expectations. Highly recommended!",
                    image: "/placeholder.svg?height=100&width=100&text=James",
                  },
                  {
                    name: "Sophia K.",
                    location: "Miami, FL",
                    text: "ShopNow's customer support team went above and beyond to help me with a return. I'll definitely be a repeat customer.",
                    image: "/placeholder.svg?height=100&width=100&text=Sophia",
                  },
                ].map((testimonial, index) => (
                  <Card key={index}>
                    <CardContent className="p-6">
                      <div className="flex items-start space-x-4">
                        <div className="relative w-12 h-12 rounded-full overflow-hidden flex-shrink-0">
                          <Image
                            src={testimonial.image || "/placeholder.svg"}
                            alt={testimonial.name}
                            fill
                            className="object-cover"
                          />
                        </div>
                        <div>
                          <h4 className="font-bold">{testimonial.name}</h4>
                          <p className="text-sm text-muted-foreground">{testimonial.location}</p>
                          <p className="mt-2 italic">"{testimonial.text}"</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </section>

        {/* CTA Section */}
        <section className="text-center bg-muted dark:bg-gray-800/50 rounded-lg p-8">
          <h2 className="text-2xl font-bold mb-4">Join Our Journey</h2>
          <p className="max-w-2xl mx-auto mb-6">
            We're always looking for passionate individuals to join our team and help us continue to grow and innovate.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild>
              <Link href="/careers">View Career Opportunities</Link>
            </Button>
            <Button variant="outline" asChild>
              <Link href="/contact">Contact Us</Link>
            </Button>
          </div>
        </section>
      </div>
    </div>
  )
}

