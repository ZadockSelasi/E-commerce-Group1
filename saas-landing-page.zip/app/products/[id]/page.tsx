import Image from "next/image"
import { notFound } from "next/navigation"
import type { Metadata } from "next"
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink } from "@/components/ui/breadcrumb"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Home, Heart, Share2, Star, ChevronRight, ChevronLeft } from "lucide-react"
import AddToCartButton from "@/components/add-to-cart-button"
import RelatedProducts from "@/components/related-products"

interface ProductPageProps {
  params: { id: string }
}

export async function generateMetadata({ params }: ProductPageProps): Promise<Metadata> {
  // In a real app, fetch the product data from your API
  const product = await getProduct(params.id)

  if (!product) {
    return {
      title: "Product Not Found",
    }
  }

  return {
    title: `${product.name} | ShopNow`,
    description: product.description,
  }
}

// This would normally fetch from your PHP backend
async function getProduct(id: string) {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 500))

  // Mock product data
  const products = {
    "1": {
      id: 1,
      name: "Premium T-Shirt",
      price: 29.99,
      images: [
        "/placeholder.svg?height=600&width=600&text=T-Shirt-1",
        "/placeholder.svg?height=600&width=600&text=T-Shirt-2",
        "/placeholder.svg?height=600&width=600&text=T-Shirt-3",
        "/placeholder.svg?height=600&width=600&text=T-Shirt-4",
      ],
      category: "Clothing",
      description:
        "A premium quality t-shirt made from 100% organic cotton. Comfortable, stylish, and perfect for everyday wear.",
      features: [
        "100% organic cotton",
        "Comfortable fit",
        "Machine washable",
        "Available in multiple colors",
        "Sustainable production",
      ],
      specifications: {
        Material: "100% Organic Cotton",
        Weight: "180g/m²",
        Care: "Machine wash cold, tumble dry low",
        Origin: "Made in Portugal",
        Fit: "Regular fit",
      },
      stock: 25,
      rating: 4.5,
      reviews: 128,
    },
    "2": {
      id: 2,
      name: "Wireless Headphones",
      price: 149.99,
      images: [
        "/placeholder.svg?height=600&width=600&text=Headphones-1",
        "/placeholder.svg?height=600&width=600&text=Headphones-2",
        "/placeholder.svg?height=600&width=600&text=Headphones-3",
      ],
      category: "Electronics",
      description:
        "High-quality wireless headphones with noise cancellation technology. Experience crystal clear sound and comfort for hours.",
      features: [
        "Active noise cancellation",
        "Bluetooth 5.0",
        "40-hour battery life",
        "Quick charge capability",
        "Comfortable over-ear design",
      ],
      specifications: {
        "Bluetooth Version": "5.0",
        "Battery Life": "Up to 40 hours",
        "Charging Time": "2 hours",
        Weight: "250g",
        Warranty: "2 years",
      },
      stock: 15,
      rating: 4.8,
      reviews: 95,
    },
  }

  return products[id as keyof typeof products] || null
}

export default async function ProductPage({ params }: ProductPageProps) {
  const product = await getProduct(params.id)

  if (!product) {
    notFound()
  }

  return (
    <div>
      <div className="container px-4 py-8 md:px-6 md:py-12">
        <Breadcrumb className="mb-6">
          <BreadcrumbItem>
            <BreadcrumbLink href="/">
              <Home className="h-4 w-4" />
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbItem>
            <BreadcrumbLink href="/products">Products</BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbItem>
            <BreadcrumbLink href={`/products/${params.id}`} isCurrentPage>
              {product.name}
            </BreadcrumbLink>
          </BreadcrumbItem>
        </Breadcrumb>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-12">
          {/* Product Images */}
          <div className="space-y-4">
            <div className="relative aspect-square overflow-hidden rounded-lg border">
              <Image
                src={product.images[0] || "/placeholder.svg"}
                alt={product.name}
                fill
                priority
                sizes="(max-width: 768px) 100vw, 50vw"
                className="object-cover"
              />
            </div>
            <div className="grid grid-cols-4 gap-4">
              {product.images.map((image, index) => (
                <div
                  key={index}
                  className="relative aspect-square overflow-hidden rounded-lg border cursor-pointer hover:border-primary"
                >
                  <Image
                    src={image || "/placeholder.svg"}
                    alt={`${product.name} - Image ${index + 1}`}
                    fill
                    sizes="(max-width: 768px) 25vw, 15vw"
                    className="object-cover"
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Product Details */}
          <div className="space-y-6">
            <div>
              <Badge variant="outline" className="mb-2">
                {product.category}
              </Badge>
              <h1 className="text-3xl font-bold">{product.name}</h1>
              <div className="flex items-center gap-2 mt-2">
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${i < Math.floor(product.rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
                    />
                  ))}
                  <span className="text-sm text-muted-foreground ml-2">({product.reviews} reviews)</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <span className="text-3xl font-bold">${product.price.toFixed(2)}</span>
              {product.stock > 0 ? (
                <Badge className="bg-green-500">In Stock</Badge>
              ) : (
                <Badge variant="destructive">Out of Stock</Badge>
              )}
            </div>

            <p className="text-muted-foreground">{product.description}</p>

            <div className="space-y-2">
              <h3 className="font-medium">Features:</h3>
              <ul className="list-disc pl-5 space-y-1">
                {product.features.map((feature, index) => (
                  <li key={index} className="text-muted-foreground">
                    {feature}
                  </li>
                ))}
              </ul>
            </div>

            <div className="flex flex-col gap-4 sm:flex-row">
              <AddToCartButton productId={product.id} />
              <Button variant="outline" size="icon">
                <Heart className="h-5 w-5" />
                <span className="sr-only">Add to wishlist</span>
              </Button>
              <Button variant="outline" size="icon">
                <Share2 className="h-5 w-5" />
                <span className="sr-only">Share product</span>
              </Button>
            </div>
          </div>
        </div>

        {/* Product Tabs */}
        <div className="mt-12">
          <Tabs defaultValue="description">
            <TabsList className="w-full justify-start">
              <TabsTrigger value="description">Description</TabsTrigger>
              <TabsTrigger value="specifications">Specifications</TabsTrigger>
              <TabsTrigger value="reviews">Reviews</TabsTrigger>
            </TabsList>
            <TabsContent value="description" className="mt-6">
              <div className="prose max-w-none">
                <p>{product.description}</p>
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel ultricies lacinia, nisl
                  nisl aliquam nisl, eget aliquam nisl nisl sit amet nisl. Sed euismod, nisl vel ultricies lacinia, nisl
                  nisl aliquam nisl, eget aliquam nisl nisl sit amet nisl.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-6">
                  <div className="relative aspect-video rounded-lg overflow-hidden">
                    <Image
                      src="/placeholder.svg?height=400&width=600&text=Product+Video"
                      alt="Product video thumbnail"
                      fill
                      className="object-cover"
                    />
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="h-16 w-16 rounded-full bg-primary/90 flex items-center justify-center">
                        <svg className="h-8 w-8 text-white" fill="currentColor" viewBox="0 0 24 24">
                          <path d="M8 5v14l11-7z" />
                        </svg>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium">Why Choose Our {product.name}?</h3>
                    <p>
                      Our products are crafted with the highest quality materials and designed to last. We take pride in
                      our craftsmanship and attention to detail.
                    </p>
                    <ul className="space-y-2">
                      <li className="flex items-center gap-2">
                        <svg className="h-5 w-5 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                        <span>Premium quality materials</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <svg className="h-5 w-5 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                        <span>Designed for comfort and durability</span>
                      </li>
                      <li className="flex items-center gap-2">
                        <svg className="h-5 w-5 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                        </svg>
                        <span>30-day money-back guarantee</span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="specifications" className="mt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {Object.entries(product.specifications).map(([key, value]) => (
                  <div key={key} className="flex justify-between border-b pb-2">
                    <span className="font-medium">{key}</span>
                    <span className="text-muted-foreground">{value}</span>
                  </div>
                ))}
              </div>
            </TabsContent>
            <TabsContent value="reviews" className="mt-6">
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="text-center">
                    <div className="text-3xl font-bold">{product.rating}</div>
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`h-4 w-4 ${i < Math.floor(product.rating) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
                        />
                      ))}
                    </div>
                    <div className="text-sm text-muted-foreground">Based on {product.reviews} reviews</div>
                  </div>
                  <div className="flex-1">
                    {/* Review distribution bars */}
                    <div className="space-y-2">
                      {[5, 4, 3, 2, 1].map((star) => (
                        <div key={star} className="flex items-center gap-2">
                          <div className="flex items-center w-12">
                            <span className="text-sm">{star}</span>
                            <Star className="h-3 w-3 ml-1 text-yellow-400 fill-yellow-400" />
                          </div>
                          <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                            <div
                              className="h-full bg-yellow-400"
                              style={{
                                width: `${Math.floor(Math.random() * 100)}%`,
                              }}
                            ></div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
                <Button>Write a Review</Button>

                {/* Sample reviews */}
                <div className="space-y-6 mt-8">
                  {[1, 2, 3].map((review) => (
                    <div key={review} className="border-b pb-6">
                      <div className="flex justify-between">
                        <div className="flex items-center gap-2">
                          <div className="relative w-10 h-10 rounded-full overflow-hidden">
                            <Image
                              src={`/placeholder.svg?height=40&width=40&text=User${review}`}
                              alt={`User ${review}`}
                              fill
                              className="object-cover"
                            />
                          </div>
                          <div>
                            <h4 className="font-medium">Customer {review}</h4>
                            <div className="flex">
                              {[...Array(5)].map((_, i) => (
                                <Star
                                  key={i}
                                  className={`h-3 w-3 ${i < 5 - (review % 2) ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
                                />
                              ))}
                            </div>
                          </div>
                        </div>
                        <div className="text-sm text-muted-foreground">{new Date().toLocaleDateString()}</div>
                      </div>
                      <p className="mt-3">
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed euismod, nisl vel ultricies
                        lacinia, nisl nisl aliquam nisl, eget aliquam nisl nisl sit amet nisl.
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </div>

        {/* Related Products */}
        <div className="mt-16">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold">You May Also Like</h2>
            <div className="flex gap-2">
              <Button variant="outline" size="icon" className="hidden sm:flex">
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="icon" className="hidden sm:flex">
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
          <RelatedProducts currentProductId={product.id} />
        </div>
      </div>
    </div>
  )
}

