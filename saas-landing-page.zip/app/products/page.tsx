import { Suspense } from "react"
import type { Metadata } from "next"
import Image from "next/image"
import ProductsView from "@/components/products/products-view"
import ProductsSkeleton from "@/components/products/products-skeleton"
import ProductsHeader from "@/components/products/products-header"

export const metadata: Metadata = {
  title: "Products | ShopNow",
  description: "Browse our collection of products",
}

export default function ProductsPage() {
  return (
    <div>
      {/* Hero Banner */}
      <div className="relative w-full h-[300px] md:h-[400px]">
        <Image
          src="/placeholder.svg?height=800&width=1920"
          alt="Products Collection"
          fill
          priority
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
          <div className="text-center text-white px-4">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Our Products</h1>
            <p className="text-lg md:text-xl max-w-2xl mx-auto">
              Discover our curated collection of high-quality products
            </p>
          </div>
        </div>
      </div>

      <div className="container px-4 py-8 md:px-6 md:py-12">
        <ProductsHeader />

        <Suspense fallback={<ProductsSkeleton />}>
          <ProductsView />
        </Suspense>
      </div>
    </div>
  )
}

