import { Suspense } from "react"
import type { Metadata } from "next"
import Image from "next/image"
import { notFound } from "next/navigation"
import CategoryHeader from "@/components/categories/category-header"
import CategoryView from "@/components/categories/category-view"
import CategorySkeleton from "@/components/categories/category-skeleton"

interface CategoryPageProps {
  params: { id: string }
}

// This would normally fetch from your PHP backend
async function getCategory(id: string) {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 500))

  // Mock category data
  const categories = {
    clothing: {
      id: "clothing",
      name: "Clothing",
      description:
        "Discover our latest collection of high-quality clothing for all occasions. From casual everyday wear to elegant formal attire.",
      image: "/placeholder.svg?height=800&width=1920&text=Clothing+Collection",
      subcategories: [
        { id: "t-shirts", name: "T-Shirts" },
        { id: "shirts", name: "Shirts" },
        { id: "pants", name: "Pants & Jeans" },
        { id: "dresses", name: "Dresses" },
        { id: "outerwear", name: "Outerwear" },
      ],
      featuredImage: "/placeholder.svg?height=600&width=600&text=Featured+Clothing",
      productCount: 120,
    },
    electronics: {
      id: "electronics",
      name: "Electronics",
      description:
        "Explore our range of cutting-edge electronics and gadgets. From smartphones and laptops to smart home devices and accessories.",
      image: "/placeholder.svg?height=800&width=1920&text=Electronics+Collection",
      subcategories: [
        { id: "smartphones", name: "Smartphones" },
        { id: "laptops", name: "Laptops & Computers" },
        { id: "audio", name: "Audio & Headphones" },
        { id: "smart-home", name: "Smart Home" },
        { id: "accessories", name: "Accessories" },
      ],
      featuredImage: "/placeholder.svg?height=600&width=600&text=Featured+Electronics",
      productCount: 85,
    },
    accessories: {
      id: "accessories",
      name: "Accessories",
      description:
        "Complete your look with our stylish accessories. From jewelry and watches to bags and wallets, find the perfect finishing touch.",
      image: "/placeholder.svg?height=800&width=1920&text=Accessories+Collection",
      subcategories: [
        { id: "jewelry", name: "Jewelry" },
        { id: "watches", name: "Watches" },
        { id: "bags", name: "Bags & Wallets" },
        { id: "hats", name: "Hats & Scarves" },
        { id: "sunglasses", name: "Sunglasses" },
      ],
      featuredImage: "/placeholder.svg?height=600&width=600&text=Featured+Accessories",
      productCount: 64,
    },
    footwear: {
      id: "footwear",
      name: "Footwear",
      description:
        "Step out in style with our footwear collection. From casual sneakers to elegant formal shoes, we have options for every occasion.",
      image: "/placeholder.svg?height=800&width=1920&text=Footwear+Collection",
      subcategories: [
        { id: "sneakers", name: "Sneakers" },
        { id: "formal", name: "Formal Shoes" },
        { id: "boots", name: "Boots" },
        { id: "sandals", name: "Sandals" },
        { id: "athletic", name: "Athletic Shoes" },
      ],
      featuredImage: "/placeholder.svg?height=600&width=600&text=Featured+Footwear",
      productCount: 47,
    },
  }

  return categories[id as keyof typeof categories] || null
}

export async function generateMetadata({ params }: CategoryPageProps): Promise<Metadata> {
  const category = await getCategory(params.id)

  if (!category) {
    return {
      title: "Category Not Found",
    }
  }

  return {
    title: `${category.name} | ShopNow`,
    description: category.description,
  }
}

export default async function CategoryPage({ params }: CategoryPageProps) {
  const category = await getCategory(params.id)

  if (!category) {
    notFound()
  }

  return (
    <div>
      {/* Category Banner */}
      <div className="relative w-full h-[300px] md:h-[400px]">
        <Image src={category.image || "/placeholder.svg"} alt={category.name} fill priority className="object-cover" />
        <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
          <div className="text-center text-white px-4">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">{category.name}</h1>
            <p className="text-lg md:text-xl max-w-2xl mx-auto">{category.description}</p>
          </div>
        </div>
      </div>

      <div className="container px-4 py-8 md:px-6 md:py-12">
        <CategoryHeader category={category} />

        <Suspense fallback={<CategorySkeleton />}>
          <CategoryView categoryId={params.id} />
        </Suspense>
      </div>
    </div>
  )
}

