import type { Metadata } from "next"
import Image from "next/image"
import Link from "next/link"
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink } from "@/components/ui/breadcrumb"
import { Card, CardContent } from "@/components/ui/card"
import { Home } from "lucide-react"

export const metadata: Metadata = {
  title: "Categories | ShopNow",
  description: "Browse our product categories",
}

// This would normally fetch from your PHP backend
async function getCategories() {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 500))

  // Mock categories data
  return [
    {
      id: "clothing",
      name: "Clothing",
      description: "Discover our latest collection of high-quality clothing for all occasions.",
      image: "/placeholder.svg?height=400&width=600&text=Clothing",
      count: 120,
      featured: true,
    },
    {
      id: "electronics",
      name: "Electronics",
      description: "Explore our range of cutting-edge electronics and gadgets.",
      image: "/placeholder.svg?height=400&width=600&text=Electronics",
      count: 85,
      featured: true,
    },
    {
      id: "accessories",
      name: "Accessories",
      description: "Complete your look with our stylish accessories.",
      image: "/placeholder.svg?height=400&width=600&text=Accessories",
      count: 64,
      featured: true,
    },
    {
      id: "footwear",
      name: "Footwear",
      description: "Step out in style with our footwear collection.",
      image: "/placeholder.svg?height=400&width=600&text=Footwear",
      count: 47,
      featured: true,
    },
    {
      id: "beauty",
      name: "Beauty & Personal Care",
      description: "Enhance your natural beauty with our premium products.",
      image: "/placeholder.svg?height=400&width=600&text=Beauty",
      count: 38,
      featured: false,
    },
    {
      id: "home",
      name: "Home & Kitchen",
      description: "Transform your living space with our home essentials.",
      image: "/placeholder.svg?height=400&width=600&text=Home",
      count: 72,
      featured: false,
    },
    {
      id: "sports",
      name: "Sports & Outdoors",
      description: "Gear up for your active lifestyle with our sports equipment.",
      image: "/placeholder.svg?height=400&width=600&text=Sports",
      count: 53,
      featured: false,
    },
    {
      id: "books",
      name: "Books & Media",
      description: "Expand your knowledge and entertainment options.",
      image: "/placeholder.svg?height=400&width=600&text=Books",
      count: 91,
      featured: false,
    },
  ]
}

export default async function CategoriesPage() {
  const categories = await getCategories()
  const featuredCategories = categories.filter((category) => category.featured)
  const otherCategories = categories.filter((category) => !category.featured)

  return (
    <div>
      {/* Hero Banner */}
      <div className="relative w-full h-[300px] md:h-[400px]">
        <Image
          src="/placeholder.svg?height=800&width=1920&text=Shop+By+Category"
          alt="Categories"
          fill
          priority
          className="object-cover"
        />
        <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
          <div className="text-center text-white px-4">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">Shop By Category</h1>
            <p className="text-lg md:text-xl max-w-2xl mx-auto">
              Browse our wide range of products organized by category
            </p>
          </div>
        </div>
      </div>

      <div className="container px-4 py-8 md:px-6 md:py-12">
        <Breadcrumb className="mb-8">
          <BreadcrumbItem>
            <BreadcrumbLink href="/">
              <Home className="h-4 w-4" />
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbItem>
            <BreadcrumbLink href="/categories" isCurrentPage>
              Categories
            </BreadcrumbLink>
          </BreadcrumbItem>
        </Breadcrumb>

        {/* Featured Categories */}
        <section className="mb-12">
          <h2 className="text-2xl font-bold mb-6">Featured Categories</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredCategories.map((category) => (
              <Link key={category.id} href={`/categories/${category.id}`} className="block group">
                <Card className="overflow-hidden h-full transition-all duration-300 group-hover:shadow-lg">
                  <div className="relative h-48 w-full">
                    <Image
                      src={category.image || "/placeholder.svg"}
                      alt={category.name}
                      fill
                      className="object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
                      <CardContent className="text-white p-4">
                        <h3 className="text-xl font-bold">{category.name}</h3>
                        <p className="text-sm text-white/80 mt-1">{category.count} Products</p>
                      </CardContent>
                    </div>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        </section>

        {/* All Categories */}
        <section>
          <h2 className="text-2xl font-bold mb-6">All Categories</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.map((category) => (
              <Link key={category.id} href={`/categories/${category.id}`} className="block group">
                <Card className="overflow-hidden h-full transition-all duration-300 group-hover:shadow-lg">
                  <div className="flex flex-col md:flex-row h-full">
                    <div className="relative h-40 md:h-auto md:w-1/3">
                      <Image
                        src={category.image || "/placeholder.svg"}
                        alt={category.name}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <CardContent className="flex-1 p-4">
                      <h3 className="text-lg font-bold group-hover:text-primary transition-colors">{category.name}</h3>
                      <p className="text-sm text-muted-foreground mt-1">{category.count} Products</p>
                      <p className="text-sm mt-2 line-clamp-2">{category.description}</p>
                    </CardContent>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        </section>

        {/* Category Benefits */}
        <section className="mt-16 bg-muted rounded-lg p-6 md:p-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="flex flex-col items-center text-center">
              <div className="bg-primary/10 p-4 rounded-full mb-4">
                <svg className="h-8 w-8 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
              </div>
              <h3 className="text-lg font-bold mb-2">Quality Products</h3>
              <p className="text-sm text-muted-foreground">
                We carefully curate our selection to ensure the highest quality products in every category.
              </p>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="bg-primary/10 p-4 rounded-full mb-4">
                <svg className="h-8 w-8 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                  />
                </svg>
              </div>
              <h3 className="text-lg font-bold mb-2">Fast Shipping</h3>
              <p className="text-sm text-muted-foreground">
                Enjoy quick delivery on all items across our diverse range of product categories.
              </p>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="bg-primary/10 p-4 rounded-full mb-4">
                <svg className="h-8 w-8 text-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z"
                  />
                </svg>
              </div>
              <h3 className="text-lg font-bold mb-2">Secure Payments</h3>
              <p className="text-sm text-muted-foreground">
                Shop with confidence knowing all transactions across categories are secure and protected.
              </p>
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}

