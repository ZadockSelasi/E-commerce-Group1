"use client"

import { useState } from "react"
import Image from "next/image"
import Link from "next/link"
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink } from "@/components/ui/breadcrumb"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent } from "@/components/ui/card"
import { Home, User, MapPin, CreditCard, Settings, LogOut, Package, Heart, Bell } from "lucide-react"
import AccountProfile from "@/components/account/account-profile"
import AccountAddresses from "@/components/account/account-addresses"
import AccountPayments from "@/components/account/account-payments"
import AccountSettings from "@/components/account/account-settings"

export default function AccountPage() {
  const [activeTab, setActiveTab] = useState("profile")

  return (
    <div className="min-h-screen">
      <div className="container px-4 py-8 md:px-6 md:py-12">
        <Breadcrumb className="mb-8">
          <BreadcrumbItem>
            <BreadcrumbLink href="/">
              <Home className="h-4 w-4" />
            </BreadcrumbLink>
          </BreadcrumbItem>
          <BreadcrumbItem>
            <BreadcrumbLink href="/account" isCurrentPage>
              My Account
            </BreadcrumbLink>
          </BreadcrumbItem>
        </Breadcrumb>

        <div className="grid grid-cols-1 md:grid-cols-[250px_1fr] gap-8">
          {/* Account Overview Card */}
          <div className="md:row-span-2">
            <Card>
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center">
                  <div className="relative w-24 h-24 rounded-full overflow-hidden mb-4 border-4 border-primary/10">
                    <Image
                      src="/placeholder.svg?height=96&width=96&text=User"
                      alt="User Avatar"
                      fill
                      className="object-cover"
                    />
                  </div>
                  <h2 className="text-xl font-bold">John Doe</h2>
                  <p className="text-sm text-muted-foreground mb-4">john.doe@example.com</p>
                  <div className="flex flex-wrap justify-center gap-2 mb-6">
                    <div className="bg-primary/10 text-primary rounded-full px-3 py-1 text-xs font-medium">
                      Premium Member
                    </div>
                    <div className="bg-primary/10 text-primary rounded-full px-3 py-1 text-xs font-medium">
                      Since 2022
                    </div>
                  </div>
                </div>

                <nav className="space-y-1 mt-4">
                  <Link
                    href="/account"
                    className={`flex items-center gap-3 px-3 py-2 text-sm font-medium rounded-md ${activeTab === "profile" ? "bg-primary/10 text-primary" : "hover:bg-muted"}`}
                    onClick={() => setActiveTab("profile")}
                  >
                    <User className="h-4 w-4" />
                    <span>Profile</span>
                  </Link>
                  <Link
                    href="/orders"
                    className="flex items-center gap-3 px-3 py-2 text-sm font-medium rounded-md hover:bg-muted"
                  >
                    <Package className="h-4 w-4" />
                    <span>Orders</span>
                  </Link>
                  <Link
                    href="/wishlist"
                    className="flex items-center gap-3 px-3 py-2 text-sm font-medium rounded-md hover:bg-muted"
                  >
                    <Heart className="h-4 w-4" />
                    <span>Wishlist</span>
                  </Link>
                  <Link
                    href="/account/notifications"
                    className="flex items-center gap-3 px-3 py-2 text-sm font-medium rounded-md hover:bg-muted"
                  >
                    <Bell className="h-4 w-4" />
                    <span>Notifications</span>
                  </Link>
                  <Link
                    href="/account/settings"
                    className="flex items-center gap-3 px-3 py-2 text-sm font-medium rounded-md hover:bg-muted"
                  >
                    <Settings className="h-4 w-4" />
                    <span>Settings</span>
                  </Link>
                  <div className="pt-4 mt-4 border-t">
                    <Button
                      variant="outline"
                      className="w-full justify-start text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/20"
                    >
                      <LogOut className="h-4 w-4 mr-2" />
                      <span>Logout</span>
                    </Button>
                  </div>
                </nav>
              </CardContent>
            </Card>
          </div>

          {/* Main Content */}
          <div>
            <Tabs defaultValue="profile" value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="profile" className="flex items-center gap-2">
                  <User className="h-4 w-4" />
                  <span className="hidden sm:inline">Profile</span>
                </TabsTrigger>
                <TabsTrigger value="addresses" className="flex items-center gap-2">
                  <MapPin className="h-4 w-4" />
                  <span className="hidden sm:inline">Addresses</span>
                </TabsTrigger>
                <TabsTrigger value="payments" className="flex items-center gap-2">
                  <CreditCard className="h-4 w-4" />
                  <span className="hidden sm:inline">Payments</span>
                </TabsTrigger>
                <TabsTrigger value="settings" className="flex items-center gap-2">
                  <Settings className="h-4 w-4" />
                  <span className="hidden sm:inline">Settings</span>
                </TabsTrigger>
              </TabsList>
              <TabsContent value="profile" className="mt-6">
                <AccountProfile />
              </TabsContent>
              <TabsContent value="addresses" className="mt-6">
                <AccountAddresses />
              </TabsContent>
              <TabsContent value="payments" className="mt-6">
                <AccountPayments />
              </TabsContent>
              <TabsContent value="settings" className="mt-6">
                <AccountSettings />
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
    </div>
  )
}

