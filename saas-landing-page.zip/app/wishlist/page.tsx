import type { Metadata } from "next"
import WishlistClientPage from "./WishlistClientPage"

export const metadata: Metadata = {
  title: "My Wishlist | ShopNow",
  description: "View and manage your wishlist items",
}

export default function WishlistPage() {
  return <WishlistClientPage />
}

