"use client"

import { useEffect, useState } from "react"
import ProductCard from "@/components/product-card"
import { Skeleton } from "@/components/ui/skeleton"

interface Product {
  id: number
  name: string
  price: number
  image: string
  category: string
}

export function FeaturedProducts() {
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // In a real app, this would fetch from your PHP backend
    // Example: fetch('/api/products/featured')
    setTimeout(() => {
      setProducts([
        {
          id: 1,
          name: "Premium T-Shirt",
          price: 29.99,
          image: "/placeholder.svg?height=300&width=300",
          category: "Clothing",
        },
        {
          id: 2,
          name: "Designer Watch",
          price: 199.99,
          image: "/placeholder.svg?height=300&width=300",
          category: "Accessories",
        },
        {
          id: 3,
          name: "Wireless Headphones",
          price: 149.99,
          image: "/placeholder.svg?height=300&width=300",
          category: "Electronics",
        },
        {
          id: 4,
          name: "Running Shoes",
          price: 89.99,
          image: "/placeholder.svg?height=300&width=300",
          category: "Footwear",
        },
      ])
      setLoading(false)
    }, 1000)
  }, [])

  if (loading) {
    return (
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4 mt-10">
        {[...Array(4)].map((_, i) => (
          <div key={i} className="flex flex-col space-y-3">
            <Skeleton className="h-[300px] w-full rounded-xl" />
            <Skeleton className="h-4 w-3/4" />
            <Skeleton className="h-4 w-1/2" />
          </div>
        ))}
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4 mt-10">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  )
}

