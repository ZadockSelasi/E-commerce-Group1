"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { ShoppingCart, Minus, Plus } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

export default function AddToCartButton({ productId }: { productId: number }) {
  const { toast } = useToast()
  const [quantity, setQuantity] = useState(1)
  const [isLoading, setIsLoading] = useState(false)

  const decreaseQuantity = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1)
    }
  }

  const increaseQuantity = () => {
    setQuantity(quantity + 1)
  }

  const addToCart = async () => {
    setIsLoading(true)

    // In a real app, this would call your PHP backend
    // Example: await fetch('/api/cart/add', {
    //   method: 'POST',
    //   body: JSON.stringify({ productId, quantity })
    // })

    setTimeout(() => {
      toast({
        title: "Added to cart",
        description: `${quantity} item(s) have been added to your cart.`,
      })
      setIsLoading(false)
    }, 1000)
  }

  return (
    <div className="flex flex-col gap-4 w-full sm:w-auto">
      <div className="flex items-center">
        <Button variant="outline" size="icon" onClick={decreaseQuantity} disabled={quantity <= 1}>
          <Minus className="h-4 w-4" />
          <span className="sr-only">Decrease quantity</span>
        </Button>
        <span className="w-12 text-center">{quantity}</span>
        <Button variant="outline" size="icon" onClick={increaseQuantity}>
          <Plus className="h-4 w-4" />
          <span className="sr-only">Increase quantity</span>
        </Button>
      </div>
      <Button className="sm:w-auto sm:min-w-[200px]" onClick={addToCart} disabled={isLoading}>
        <ShoppingCart className="mr-2 h-4 w-4" />
        {isLoading ? "Adding..." : "Add to Cart"}
      </Button>
    </div>
  )
}

