"use client"

import { useEffect, useState } from "react"
import ProductCard from "@/components/product-card"
import { Pagination } from "@/components/ui/pagination"

interface Product {
  id: number
  name: string
  price: number
  image: string
  category: string
  discount?: number
}

export default function ProductList() {
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(3)

  useEffect(() => {
    // In a real app, this would fetch from your PHP backend with pagination
    // Example: fetch(`/api/products?page=${currentPage}`)
    setLoading(true)

    setTimeout(() => {
      const mockProducts = [
        {
          id: 1,
          name: "Premium T-Shirt",
          price: 29.99,
          image: "/placeholder.svg?height=300&width=300",
          category: "Clothing",
        },
        {
          id: 2,
          name: "Designer Watch",
          price: 199.99,
          image: "/placeholder.svg?height=300&width=300",
          category: "Accessories",
          discount: 10,
        },
        {
          id: 3,
          name: "Wireless Headphones",
          price: 149.99,
          image: "/placeholder.svg?height=300&width=300",
          category: "Electronics",
        },
        {
          id: 4,
          name: "Running Shoes",
          price: 89.99,
          image: "/placeholder.svg?height=300&width=300",
          category: "Footwear",
          discount: 15,
        },
        {
          id: 5,
          name: "Leather Wallet",
          price: 49.99,
          image: "/placeholder.svg?height=300&width=300",
          category: "Accessories",
        },
        {
          id: 6,
          name: "Smartphone Case",
          price: 19.99,
          image: "/placeholder.svg?height=300&width=300",
          category: "Electronics",
        },
        {
          id: 7,
          name: "Denim Jeans",
          price: 59.99,
          image: "/placeholder.svg?height=300&width=300",
          category: "Clothing",
          discount: 20,
        },
        {
          id: 8,
          name: "Sunglasses",
          price: 79.99,
          image: "/placeholder.svg?height=300&width=300",
          category: "Accessories",
        },
        {
          id: 9,
          name: "Bluetooth Speaker",
          price: 129.99,
          image: "/placeholder.svg?height=300&width=300",
          category: "Electronics",
          discount: 5,
        },
      ]

      setProducts(mockProducts)
      setLoading(false)
    }, 1000)
  }, [currentPage])

  const handlePageChange = (page: number) => {
    setCurrentPage(page)
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  if (loading && products.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-current border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"></div>
        <p className="mt-4 text-muted-foreground">Loading products...</p>
      </div>
    )
  }

  return (
    <div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>

      <div className="mt-12 flex justify-center">
        <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={handlePageChange} />
      </div>
    </div>
  )
}

