"use client"

import { useState } from "react"
import Image from "next/image"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { X } from "lucide-react"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

// Define subcategories based on category
const subcategoriesMap: Record<string, Array<{ id: string; name: string; image: string }>> = {
  clothing: [
    { id: "t-shirts", name: "T-Shirts", image: "/placeholder.svg?height=60&width=60&text=T-Shirts" },
    { id: "shirts", name: "Shirts", image: "/placeholder.svg?height=60&width=60&text=Shirts" },
    { id: "pants", name: "Pants & Jeans", image: "/placeholder.svg?height=60&width=60&text=Pants" },
    { id: "dresses", name: "Dresses", image: "/placeholder.svg?height=60&width=60&text=Dresses" },
    { id: "outerwear", name: "Outerwear", image: "/placeholder.svg?height=60&width=60&text=Outerwear" },
  ],
  electronics: [
    { id: "smartphones", name: "Smartphones", image: "/placeholder.svg?height=60&width=60&text=Phones" },
    { id: "laptops", name: "Laptops & Computers", image: "/placeholder.svg?height=60&width=60&text=Laptops" },
    { id: "audio", name: "Audio & Headphones", image: "/placeholder.svg?height=60&width=60&text=Audio" },
    { id: "smart-home", name: "Smart Home", image: "/placeholder.svg?height=60&width=60&text=Smart" },
    { id: "accessories", name: "Accessories", image: "/placeholder.svg?height=60&width=60&text=Acc" },
  ],
  accessories: [
    { id: "jewelry", name: "Jewelry", image: "/placeholder.svg?height=60&width=60&text=Jewelry" },
    { id: "watches", name: "Watches", image: "/placeholder.svg?height=60&width=60&text=Watches" },
    { id: "bags", name: "Bags & Wallets", image: "/placeholder.svg?height=60&width=60&text=Bags" },
    { id: "hats", name: "Hats & Scarves", image: "/placeholder.svg?height=60&width=60&text=Hats" },
    { id: "sunglasses", name: "Sunglasses", image: "/placeholder.svg?height=60&width=60&text=Glasses" },
  ],
  footwear: [
    { id: "sneakers", name: "Sneakers", image: "/placeholder.svg?height=60&width=60&text=Sneakers" },
    { id: "formal", name: "Formal Shoes", image: "/placeholder.svg?height=60&width=60&text=Formal" },
    { id: "boots", name: "Boots", image: "/placeholder.svg?height=60&width=60&text=Boots" },
    { id: "sandals", name: "Sandals", image: "/placeholder.svg?height=60&width=60&text=Sandals" },
    { id: "athletic", name: "Athletic Shoes", image: "/placeholder.svg?height=60&width=60&text=Athletic" },
  ],
}

interface CategoryFiltersProps {
  categoryId: string
  selectedSubcategory: string
  priceRange: [number, number]
  onSubcategoryChange: (subcategory: string) => void
  onPriceChange: (min: number, max: number) => void
  onClearFilters: () => void
}

export default function CategoryFilters({
  categoryId,
  selectedSubcategory,
  priceRange,
  onSubcategoryChange,
  onPriceChange,
  onClearFilters,
}: CategoryFiltersProps) {
  const [localPriceRange, setLocalPriceRange] = useState<[number, number]>(priceRange)

  const handlePriceChange = (value: number[]) => {
    setLocalPriceRange([value[0], value[1]])
  }

  const applyPriceRange = () => {
    onPriceChange(localPriceRange[0], localPriceRange[1])
  }

  const subcategories = subcategoriesMap[categoryId] || []
  const hasActiveFilters = selectedSubcategory || priceRange[0] > 0 || priceRange[1] < 500

  // Get category-specific attributes
  const getCategoryAttributes = () => {
    switch (categoryId) {
      case "clothing":
        return [
          { id: "size", name: "Size", options: ["XS", "S", "M", "L", "XL", "XXL"] },
          { id: "color", name: "Color", options: ["Black", "White", "Blue", "Red", "Green"] },
          { id: "material", name: "Material", options: ["Cotton", "Polyester", "Wool", "Denim", "Linen"] },
        ]
      case "electronics":
        return [
          { id: "brand", name: "Brand", options: ["Apple", "Samsung", "Sony", "LG", "Bose"] },
          { id: "condition", name: "Condition", options: ["New", "Refurbished", "Used"] },
          { id: "warranty", name: "Warranty", options: ["1 Year", "2 Years", "3 Years", "No Warranty"] },
        ]
      case "accessories":
        return [
          { id: "material", name: "Material", options: ["Leather", "Metal", "Fabric", "Plastic", "Wood"] },
          { id: "color", name: "Color", options: ["Black", "Silver", "Gold", "Brown", "Multi"] },
          { id: "style", name: "Style", options: ["Casual", "Formal", "Sporty", "Vintage", "Luxury"] },
        ]
      case "footwear":
        return [
          { id: "size", name: "Size", options: ["6", "7", "8", "9", "10", "11", "12"] },
          { id: "color", name: "Color", options: ["Black", "White", "Brown", "Blue", "Red"] },
          { id: "material", name: "Material", options: ["Leather", "Canvas", "Synthetic", "Suede", "Mesh"] },
        ]
      default:
        return []
    }
  }

  const categoryAttributes = getCategoryAttributes()

  return (
    <div className="space-y-6">
      {hasActiveFilters && (
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-medium">Active Filters</h3>
            <Button variant="ghost" size="sm" onClick={onClearFilters} className="h-8 px-2 text-xs">
              Clear all
            </Button>
          </div>
          <div className="flex flex-wrap gap-2">
            {selectedSubcategory && (
              <Badge variant="secondary" className="flex items-center gap-1">
                {subcategories.find((c) => c.id === selectedSubcategory)?.name || selectedSubcategory}
                <Button
                  variant="ghost"
                  size="icon"
                  className="h-4 w-4 p-0 ml-1"
                  onClick={() => onSubcategoryChange("")}
                >
                  <X className="h-3 w-3" />
                  <span className="sr-only">Remove</span>
                </Button>
              </Badge>
            )}
            {(priceRange[0] > 0 || priceRange[1] < 500) && (
              <Badge variant="secondary" className="flex items-center gap-1">
                ${priceRange[0]} - ${priceRange[1]}
                <Button variant="ghost" size="icon" className="h-4 w-4 p-0 ml-1" onClick={() => onPriceChange(0, 500)}>
                  <X className="h-3 w-3" />
                  <span className="sr-only">Remove</span>
                </Button>
              </Badge>
            )}
          </div>
        </div>
      )}

      <Accordion
        type="multiple"
        defaultValue={["subcategories", "price", ...categoryAttributes.map((attr) => attr.id)]}
      >
        <AccordionItem value="subcategories">
          <AccordionTrigger>Subcategories</AccordionTrigger>
          <AccordionContent>
            <div className="grid grid-cols-1 gap-3 pt-1">
              {subcategories.map((subcategory) => (
                <div
                  key={subcategory.id}
                  className={`flex items-center space-x-3 p-2 rounded-lg cursor-pointer transition-colors ${
                    selectedSubcategory === subcategory.id
                      ? "bg-primary/10 border border-primary/30"
                      : "hover:bg-muted border border-transparent"
                  }`}
                  onClick={() => onSubcategoryChange(selectedSubcategory === subcategory.id ? "" : subcategory.id)}
                >
                  <div className="relative w-12 h-12 rounded-md overflow-hidden border">
                    <Image
                      src={subcategory.image || "/placeholder.svg"}
                      alt={subcategory.name}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">{subcategory.name}</p>
                  </div>
                  <Checkbox checked={selectedSubcategory === subcategory.id} className="pointer-events-none" />
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="price">
          <AccordionTrigger>Price Range</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4 pt-2">
              <Slider
                min={0}
                max={500}
                step={10}
                value={[localPriceRange[0], localPriceRange[1]]}
                onValueChange={handlePriceChange}
                className="my-6"
              />
              <div className="flex items-center justify-between">
                <span className="text-sm">${localPriceRange[0]}</span>
                <span className="text-sm">${localPriceRange[1]}</span>
              </div>
              <Button size="sm" onClick={applyPriceRange} className="w-full">
                Apply
              </Button>
            </div>
          </AccordionContent>
        </AccordionItem>

        {/* Category-specific attributes */}
        {categoryAttributes.map((attribute) => (
          <AccordionItem key={attribute.id} value={attribute.id}>
            <AccordionTrigger>{attribute.name}</AccordionTrigger>
            <AccordionContent>
              <div className="space-y-2 pt-1">
                {attribute.options.map((option) => (
                  <div key={option} className="flex items-center space-x-2">
                    <Checkbox id={`${attribute.id}-${option}`} />
                    <label
                      htmlFor={`${attribute.id}-${option}`}
                      className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      {option}
                    </label>
                  </div>
                ))}
              </div>
            </AccordionContent>
          </AccordionItem>
        ))}

        <AccordionItem value="ratings">
          <AccordionTrigger>Ratings</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2 pt-1">
              {[5, 4, 3, 2, 1].map((rating) => (
                <div key={rating} className="flex items-center space-x-2">
                  <Checkbox id={`rating-${rating}`} />
                  <label
                    htmlFor={`rating-${rating}`}
                    className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 flex items-center"
                  >
                    <div className="flex">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <svg
                          key={i}
                          className={`h-4 w-4 ${i < rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
                          xmlns="http://www.w3.org/2000/svg"
                          viewBox="0 0 24 24"
                        >
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                        </svg>
                      ))}
                    </div>
                    <span className="ml-1">& Up</span>
                  </label>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="availability">
          <AccordionTrigger>Availability</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2 pt-1">
              <div className="flex items-center space-x-2">
                <Checkbox id="in-stock" />
                <label
                  htmlFor="in-stock"
                  className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  In Stock
                </label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="out-of-stock" />
                <label
                  htmlFor="out-of-stock"
                  className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  Out of Stock
                </label>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>

      {/* Featured Products */}
      <div className="mt-6 pt-6 border-t">
        <h3 className="text-sm font-medium mb-4">
          Popular in {categoryId.charAt(0).toUpperCase() + categoryId.slice(1)}
        </h3>
        <div className="space-y-4">
          {[1, 2, 3].map((item) => (
            <div key={item} className="flex items-start space-x-3">
              <div className="relative w-16 h-16 rounded-md overflow-hidden border">
                <Image
                  src={`/placeholder.svg?height=64&width=64&text=${categoryId}${item}`}
                  alt={`Popular ${categoryId} ${item}`}
                  fill
                  className="object-cover"
                />
              </div>
              <div>
                <h4 className="text-sm font-medium">
                  {categoryId.charAt(0).toUpperCase() + categoryId.slice(1)} Item {item}
                </h4>
                <p className="text-sm text-muted-foreground">${(Math.random() * 100 + 20).toFixed(2)}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

