import Link from "next/link"
import { Breadcrumb, BreadcrumbItem, BreadcrumbLink } from "@/components/ui/breadcrumb"
import { Home } from "lucide-react"
import { Badge } from "@/components/ui/badge"

interface Subcategory {
  id: string
  name: string
}

interface Category {
  id: string
  name: string
  description: string
  subcategories: Subcategory[]
  productCount: number
}

interface CategoryHeaderProps {
  category: Category
}

export default function CategoryHeader({ category }: CategoryHeaderProps) {
  return (
    <div className="space-y-6">
      <Breadcrumb>
        <BreadcrumbItem>
          <BreadcrumbLink href="/">
            <Home className="h-4 w-4" />
          </BreadcrumbLink>
        </BreadcrumbItem>
        <BreadcrumbItem>
          <BreadcrumbLink href="/categories">Categories</BreadcrumbLink>
        </BreadcrumbItem>
        <BreadcrumbItem>
          <BreadcrumbLink href={`/categories/${category.id}`} isCurrentPage>
            {category.name}
          </BreadcrumbLink>
        </BreadcrumbItem>
      </Breadcrumb>

      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-2xl font-bold tracking-tight">{category.name}</h2>
            <Badge variant="outline">{category.productCount} Products</Badge>
          </div>
          <p className="text-muted-foreground mt-1 md:max-w-2xl">{category.description}</p>
        </div>
      </div>

      {/* Subcategories */}
      <div className="flex flex-wrap gap-2">
        {category.subcategories.map((subcategory) => (
          <Link
            key={subcategory.id}
            href={`/categories/${category.id}?subcategory=${subcategory.id}`}
            className="px-4 py-2 rounded-full bg-muted hover:bg-muted/80 transition-colors text-sm font-medium"
          >
            {subcategory.name}
          </Link>
        ))}
      </div>
    </div>
  )
}

