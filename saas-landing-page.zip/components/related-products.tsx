"use client"

import { useEffect, useState } from "react"
import ProductCard from "@/components/product-card"

interface Product {
  id: number
  name: string
  price: number
  image: string
  category: string
  discount?: number
}

export default function RelatedProducts({ currentProductId }: { currentProductId: number }) {
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // In a real app, this would fetch from your PHP backend
    // Example: fetch(`/api/products/related?id=${currentProductId}`)
    setTimeout(() => {
      setProducts([
        {
          id: 2,
          name: "Designer Watch",
          price: 199.99,
          image: "/placeholder.svg?height=300&width=300",
          category: "Accessories",
          discount: 10,
        },
        {
          id: 3,
          name: "Wireless Headphones",
          price: 149.99,
          image: "/placeholder.svg?height=300&width=300",
          category: "Electronics",
        },
        {
          id: 4,
          name: "Running Shoes",
          price: 89.99,
          image: "/placeholder.svg?height=300&width=300",
          category: "Footwear",
          discount: 15,
        },
        {
          id: 5,
          name: "Leather Wallet",
          price: 49.99,
          image: "/placeholder.svg?height=300&width=300",
          category: "Accessories",
        },
      ])
      setLoading(false)
    }, 1000)
  }, [currentProductId])

  if (loading) {
    return (
      <div className="text-center py-12">
        <div className="inline-block h-8 w-8 animate-spin rounded-full border-4 border-solid border-current border-r-transparent align-[-0.125em] motion-reduce:animate-[spin_1.5s_linear_infinite]"></div>
        <p className="mt-4 text-muted-foreground">Loading related products...</p>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
      {products.map((product) => (
        <ProductCard key={product.id} product={product} />
      ))}
    </div>
  )
}

