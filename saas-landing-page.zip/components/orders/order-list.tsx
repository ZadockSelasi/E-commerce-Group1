"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Pagination,
  PaginationContent,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination"
import { ChevronRight, Package, Truck, CheckCircle, Clock, X } from "lucide-react"

interface Order {
  id: string
  orderNumber: string
  date: string
  total: number
  status: "processing" | "shipped" | "delivered" | "cancelled"
  items: {
    id: string
    name: string
    price: number
    quantity: number
    image: string
  }[]
}

interface OrderListProps {
  status: string
}

export default function OrderList({ status }: OrderListProps) {
  const [orders, setOrders] = useState<Order[]>([])
  const [loading, setLoading] = useState(true)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(3)

  useEffect(() => {
    // In a real app, this would fetch from your PHP backend
    // Example: fetch(`/api/orders?status=${status}&page=${currentPage}`)
    setLoading(true)

    const fetchOrders = () => {
      const mockOrders: Order[] = [
        {
          id: "ord1",
          orderNumber: "ORD-2023-1234",
          date: "2023-03-15",
          total: 129.99,
          status: "delivered",
          items: [
            {
              id: "item1",
              name: "Wireless Headphones",
              price: 79.99,
              quantity: 1,
              image: "/placeholder.svg?height=80&width=80&text=Headphones",
            },
            {
              id: "item2",
              name: "Phone Case",
              price: 24.99,
              quantity: 2,
              image: "/placeholder.svg?height=80&width=80&text=Case",
            },
          ],
        },
        {
          id: "ord2",
          orderNumber: "ORD-2023-1235",
          date: "2023-03-20",
          total: 349.99,
          status: "shipped",
          items: [
            {
              id: "item3",
              name: "Smart Watch",
              price: 249.99,
              quantity: 1,
              image: "/placeholder.svg?height=80&width=80&text=Watch",
            },
            {
              id: "item4",
              name: "Wireless Charger",
              price: 49.99,
              quantity: 2,
              image: "/placeholder.svg?height=80&width=80&text=Charger",
            },
          ],
        },
        {
          id: "ord3",
          orderNumber: "ORD-2023-1236",
          date: "2023-03-25",
          total: 199.99,
          status: "processing",
          items: [
            {
              id: "item5",
              name: "Bluetooth Speaker",
              price: 199.99,
              quantity: 1,
              image: "/placeholder.svg?height=80&width=80&text=Speaker",
            },
          ],
        },
      ]

      // Filter orders based on status
      const filteredOrders = status === "all" ? mockOrders : mockOrders.filter((order) => order.status === status)

      setOrders(filteredOrders)
      setLoading(false)
    }

    // Simulate API call
    setTimeout(fetchOrders, 1000)
  }, [status, currentPage])

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "processing":
        return (
          <Badge
            variant="outline"
            className="bg-blue-50 text-blue-600 border-blue-200 dark:bg-blue-950/20 dark:text-blue-400 dark:border-blue-800"
          >
            <Clock className="h-3 w-3 mr-1" />
            Processing
          </Badge>
        )
      case "shipped":
        return (
          <Badge
            variant="outline"
            className="bg-amber-50 text-amber-600 border-amber-200 dark:bg-amber-950/20 dark:text-amber-400 dark:border-amber-800"
          >
            <Truck className="h-3 w-3 mr-1" />
            Shipped
          </Badge>
        )
      case "delivered":
        return (
          <Badge
            variant="outline"
            className="bg-green-50 text-green-600 border-green-200 dark:bg-green-950/20 dark:text-green-400 dark:border-green-800"
          >
            <CheckCircle className="h-3 w-3 mr-1" />
            Delivered
          </Badge>
        )
      case "cancelled":
        return (
          <Badge
            variant="outline"
            className="bg-red-50 text-red-600 border-red-200 dark:bg-red-950/20 dark:text-red-400 dark:border-red-800"
          >
            <X className="h-3 w-3 mr-1" />
            Cancelled
          </Badge>
        )
      default:
        return null
    }
  }

  if (loading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <Card key={i} className="animate-pulse">
            <CardHeader className="pb-2">
              <div className="flex justify-between">
                <div className="h-6 w-32 bg-muted rounded"></div>
                <div className="h-6 w-24 bg-muted rounded"></div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row gap-4">
                <div className="h-20 w-full md:w-64 bg-muted rounded"></div>
                <div className="space-y-2 flex-1">
                  <div className="h-4 w-full bg-muted rounded"></div>
                  <div className="h-4 w-3/4 bg-muted rounded"></div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  if (orders.length === 0) {
    return (
      <div className="text-center py-12">
        <Package className="h-12 w-12 mx-auto text-muted-foreground" />
        <h3 className="mt-4 text-lg font-medium">No orders found</h3>
        <p className="mt-2 text-muted-foreground">
          {status === "all" ? "You haven't placed any orders yet." : `You don't have any ${status} orders.`}
        </p>
        <Button asChild className="mt-4">
          <Link href="/products">Start Shopping</Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="space-y-4">
        {orders.map((order) => (
          <Card key={order.id}>
            <CardHeader className="pb-2">
              <div className="flex flex-col md:flex-row justify-between md:items-center gap-2">
                <div>
                  <CardTitle className="text-lg">Order #{order.orderNumber}</CardTitle>
                  <CardDescription>Placed on {new Date(order.date).toLocaleDateString()}</CardDescription>
                </div>
                <div className="flex items-center gap-2">
                  {getStatusBadge(order.status)}
                  <span className="font-medium">${order.total.toFixed(2)}</span>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex gap-2 overflow-x-auto pb-2 md:pb-0">
                  {order.items.map((item) => (
                    <div key={item.id} className="relative min-w-[80px] h-20 rounded-md overflow-hidden border">
                      <Image src={item.image || "/placeholder.svg"} alt={item.name} fill className="object-cover" />
                      {item.quantity > 1 && (
                        <div className="absolute bottom-0 right-0 bg-background/80 backdrop-blur-sm text-xs font-medium px-1 rounded-tl">
                          x{item.quantity}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
                <div className="flex-1 flex flex-col justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">
                      {order.items.reduce((total, item) => total + item.quantity, 0)} items
                    </p>
                  </div>
                  <div className="flex justify-end">
                    <Button variant="outline" size="sm" asChild>
                      <Link href={`/orders/${order.id}`}>
                        View Details
                        <ChevronRight className="ml-1 h-4 w-4" />
                      </Link>
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Pagination>
        <PaginationContent>
          <PaginationItem>
            <PaginationPrevious
              href="#"
              onClick={(e) => {
                e.preventDefault()
                if (currentPage > 1) setCurrentPage(currentPage - 1)
              }}
            />
          </PaginationItem>
          {[...Array(totalPages)].map((_, i) => (
            <PaginationItem key={i}>
              <PaginationLink
                href="#"
                isActive={currentPage === i + 1}
                onClick={(e) => {
                  e.preventDefault()
                  setCurrentPage(i + 1)
                }}
              >
                {i + 1}
              </PaginationLink>
            </PaginationItem>
          ))}
          <PaginationItem>
            <PaginationNext
              href="#"
              onClick={(e) => {
                e.preventDefault()
                if (currentPage < totalPages) setCurrentPage(currentPage + 1)
              }}
            />
          </PaginationItem>
        </PaginationContent>
      </Pagination>
    </div>
  )
}

