import * as React from "react"
import Link from "next/link"
import { ChevronRight } from "lucide-react"
import { cn } from "@/lib/utils"

export interface BreadcrumbProps extends React.HTMLAttributes<HTMLElement> {
  separator?: React.ReactNode
}

export function Breadcrumb({ separator = <ChevronRight className="h-4 w-4" />, className, ...props }: BreadcrumbProps) {
  return <nav aria-label="breadcrumb" className={cn("flex items-center text-sm", className)} {...props} />
}

export interface BreadcrumbItemProps extends React.HTMLAttributes<HTMLLIElement> {}

export function BreadcrumbItem({ className, ...props }: BreadcrumbItemProps) {
  return <li className={cn("inline-flex items-center", className)} {...props} />
}

export interface BreadcrumbLinkProps extends React.AnchorHTMLAttributes<HTMLAnchorElement> {
  asChild?: boolean
  href: string
  isCurrentPage?: boolean
}

export function BreadcrumbLink({ asChild, href, isCurrentPage, className, ...props }: BreadcrumbLinkProps) {
  const Comp = asChild ? React.Fragment : Link

  return isCurrentPage ? (
    <span className={cn("text-muted-foreground font-medium", className)} aria-current="page" {...props} />
  ) : (
    <Comp
      href={href}
      className={cn("text-muted-foreground hover:text-foreground transition-colors", className)}
      {...props}
    />
  )
}

export interface BreadcrumbSeparatorProps extends React.HTMLAttributes<HTMLLIElement> {}

export function BreadcrumbSeparator({ className, ...props }: BreadcrumbSeparatorProps) {
  return <li className={cn("mx-2 text-muted-foreground", className)} {...props} />
}

export interface BreadcrumbPageProps extends React.HTMLAttributes<HTMLLIElement> {}

export function BreadcrumbPage({ className, ...props }: BreadcrumbPageProps) {
  return <li className={cn("text-foreground font-medium", className)} aria-current="page" {...props} />
}

// Compound component wrapper
Breadcrumb.Item = BreadcrumbItem
Breadcrumb.Link = BreadcrumbLink
Breadcrumb.Separator = BreadcrumbSeparator
Breadcrumb.Page = BreadcrumbPage

