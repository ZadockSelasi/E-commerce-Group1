"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ShoppingCart } from "lucide-react"
import { useToast } from "@/components/ui/use-toast"

interface Product {
  id: number
  name: string
  price: number
  image: string
  category: string
  discount?: number
}

export default function ProductCard({ product }: { product: Product }) {
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)

  const addToCart = async () => {
    setIsLoading(true)

    // In a real app, this would call your PHP backend
    // Example: await fetch('/api/cart/add', { method: 'POST', body: JSON.stringify({ productId: product.id }) })

    setTimeout(() => {
      toast({
        title: "Added to cart",
        description: `${product.name} has been added to your cart.`,
      })
      setIsLoading(false)
    }, 1000)
  }

  return (
    <Card className="overflow-hidden">
      <Link href={`/products/${product.id}`}>
        <div className="overflow-hidden">
          <Image
            src={product.image || "/placeholder.svg"}
            alt={product.name}
            width={300}
            height={300}
            className="w-full h-[300px] object-cover transition-transform hover:scale-105"
          />
        </div>
      </Link>
      <CardHeader className="p-4">
        <div className="flex justify-between items-start">
          <div>
            <Badge variant="outline" className="mb-2">
              {product.category}
            </Badge>
            <CardTitle className="text-lg">{product.name}</CardTitle>
          </div>
          {product.discount && <Badge className="bg-red-500">{product.discount}% OFF</Badge>}
        </div>
      </CardHeader>
      <CardContent className="p-4 pt-0">
        <div className="flex items-center gap-2">
          <span className="text-xl font-bold">${product.price.toFixed(2)}</span>
          {product.discount && (
            <span className="text-sm text-muted-foreground line-through">
              ${(product.price / (1 - product.discount / 100)).toFixed(2)}
            </span>
          )}
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0">
        <Button className="w-full" onClick={addToCart} disabled={isLoading}>
          <ShoppingCart className="mr-2 h-4 w-4" />
          {isLoading ? "Adding..." : "Add to Cart"}
        </Button>
      </CardFooter>
    </Card>
  )
}

