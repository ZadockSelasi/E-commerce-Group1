"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useToast } from "@/components/ui/use-toast"
import { Heart, ShoppingCart, Trash2, Share2 } from "lucide-react"

interface WishlistItem {
  id: number
  name: string
  price: number
  originalPrice?: number
  discount?: number
  image: string
  category: string
  inStock: boolean
  dateAdded: string
}

export default function WishlistItems() {
  const { toast } = useToast()
  const [items, setItems] = useState<WishlistItem[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // In a real app, this would fetch from your PHP backend
    // Example: fetch('/api/wishlist')
    setLoading(true)

    const fetchWishlistItems = () => {
      const mockItems: WishlistItem[] = [
        {
          id: 1,
          name: "Premium Wireless Headphones",
          price: 149.99,
          originalPrice: 199.99,
          discount: 25,
          image: "/placeholder.svg?height=300&width=300&text=Headphones",
          category: "Electronics",
          inStock: true,
          dateAdded: "2023-03-10",
        },
        {
          id: 2,
          name: "Leather Crossbody Bag",
          price: 89.99,
          image: "/placeholder.svg?height=300&width=300&text=Bag",
          category: "Accessories",
          inStock: true,
          dateAdded: "2023-03-12",
        },
        {
          id: 3,
          name: "Smart Watch Series 5",
          price: 299.99,
          originalPrice: 349.99,
          discount: 15,
          image: "/placeholder.svg?height=300&width=300&text=Watch",
          category: "Electronics",
          inStock: false,
          dateAdded: "2023-03-15",
        },
        {
          id: 4,
          name: "Casual Sneakers",
          price: 79.99,
          image: "/placeholder.svg?height=300&width=300&text=Sneakers",
          category: "Footwear",
          inStock: true,
          dateAdded: "2023-03-18",
        },
        {
          id: 5,
          name: "Portable Bluetooth Speaker",
          price: 59.99,
          image: "/placeholder.svg?height=300&width=300&text=Speaker",
          category: "Electronics",
          inStock: true,
          dateAdded: "2023-03-20",
        },
        {
          id: 6,
          name: "Stainless Steel Water Bottle",
          price: 24.99,
          originalPrice: 34.99,
          discount: 30,
          image: "/placeholder.svg?height=300&width=300&text=Bottle",
          category: "Accessories",
          inStock: true,
          dateAdded: "2023-03-22",
        },
      ]

      setItems(mockItems)
      setLoading(false)
    }

    // Simulate API call
    setTimeout(fetchWishlistItems, 1000)
  }, [])

  const removeFromWishlist = (id: number) => {
    setItems(items.filter((item) => item.id !== id))

    toast({
      title: "Item removed",
      description: "The item has been removed from your wishlist.",
    })
  }

  const addToCart = (id: number) => {
    // In a real app, this would call your PHP backend
    // Example: await fetch('/api/cart/add', { method: 'POST', body: JSON.stringify({ productId: id }) })

    toast({
      title: "Added to cart",
      description: "The item has been added to your cart.",
    })
  }

  const shareItem = (id: number) => {
    // In a real app, this would open a share dialog

    toast({
      title: "Share link copied",
      description: "The product link has been copied to your clipboard.",
    })
  }

  if (loading) {
    return (
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {[1, 2, 3, 4].map((i) => (
          <Card key={i} className="animate-pulse">
            <div className="relative aspect-square bg-muted"></div>
            <CardContent className="p-4">
              <div className="space-y-2">
                <div className="h-4 w-1/4 bg-muted rounded"></div>
                <div className="h-5 w-3/4 bg-muted rounded"></div>
                <div className="h-4 w-1/2 bg-muted rounded"></div>
              </div>
            </CardContent>
            <CardFooter className="p-4 pt-0">
              <div className="h-9 w-full bg-muted rounded"></div>
            </CardFooter>
          </Card>
        ))}
      </div>
    )
  }

  if (items.length === 0) {
    return (
      <div className="text-center py-12">
        <Heart className="h-12 w-12 mx-auto text-muted-foreground" />
        <h3 className="mt-4 text-lg font-medium">Your wishlist is empty</h3>
        <p className="mt-2 text-muted-foreground">Items added to your wishlist will appear here.</p>
        <Button asChild className="mt-4">
          <Link href="/products">Start Shopping</Link>
        </Button>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
      {items.map((item) => (
        <Card key={item.id} className="overflow-hidden group">
          <div className="relative">
            <Link href={`/products/${item.id}`}>
              <div className="relative aspect-square overflow-hidden">
                <Image
                  src={item.image || "/placeholder.svg"}
                  alt={item.name}
                  fill
                  className="object-cover transition-transform duration-300 group-hover:scale-105"
                />
                {item.discount && <Badge className="absolute top-2 right-2 bg-red-500">{item.discount}% OFF</Badge>}
                {!item.inStock && (
                  <div className="absolute inset-0 bg-background/80 backdrop-blur-sm flex items-center justify-center">
                    <Badge variant="outline" className="bg-background text-foreground border-foreground">
                      Out of Stock
                    </Badge>
                  </div>
                )}
              </div>
            </Link>
            <Button
              variant="outline"
              size="icon"
              className="absolute top-2 left-2 bg-background/80 backdrop-blur-sm hover:bg-background"
              onClick={() => removeFromWishlist(item.id)}
            >
              <Trash2 className="h-4 w-4 text-red-500" />
              <span className="sr-only">Remove from wishlist</span>
            </Button>
          </div>

          <CardContent className="p-4">
            <div className="mb-2">
              <Badge variant="outline" className="text-xs">
                {item.category}
              </Badge>
            </div>
            <Link href={`/products/${item.id}`} className="hover:underline">
              <h3 className="font-medium line-clamp-1">{item.name}</h3>
            </Link>
            <div className="flex items-center gap-2 mt-2">
              <span className="font-bold">${item.price.toFixed(2)}</span>
              {item.originalPrice && (
                <span className="text-sm text-muted-foreground line-through">${item.originalPrice.toFixed(2)}</span>
              )}
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              Added on {new Date(item.dateAdded).toLocaleDateString()}
            </p>
          </CardContent>

          <CardFooter className="p-4 pt-0 flex gap-2">
            <Button className="flex-1" size="sm" disabled={!item.inStock} onClick={() => addToCart(item.id)}>
              <ShoppingCart className="h-4 w-4 mr-2" />
              Add to Cart
            </Button>
            <Button variant="outline" size="icon" className="h-9 w-9" onClick={() => shareItem(item.id)}>
              <Share2 className="h-4 w-4" />
              <span className="sr-only">Share</span>
            </Button>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}

