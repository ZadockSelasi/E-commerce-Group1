"use client"

import { useState, useEffect } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import ProductGrid from "@/components/products/product-grid"
import ProductFilters from "@/components/products/product-filters"
import ProductsSort from "@/components/products/products-sort"
import ProductsPagination from "@/components/products/products-pagination"
import { Button } from "@/components/ui/button"
import { Filter, X } from "lucide-react"
import { useMediaQuery } from "@/hooks/use-media-query"

interface Product {
  id: number
  name: string
  price: number
  image: string
  category: string
  discount?: number
  rating: number
  reviews: number
}

export default function ProductsView() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [products, setProducts] = useState<Product[]>([])
  const [loading, setLoading] = useState(true)
  const [totalProducts, setTotalProducts] = useState(0)
  const [currentPage, setCurrentPage] = useState(1)
  const [totalPages, setTotalPages] = useState(5)
  const [filtersOpen, setFiltersOpen] = useState(false)
  const isDesktop = useMediaQuery("(min-width: 1024px)")

  // Get query parameters
  const category = searchParams.get("category") || ""
  const minPrice = searchParams.get("minPrice") || ""
  const maxPrice = searchParams.get("maxPrice") || ""
  const sort = searchParams.get("sort") || "newest"
  const page = Number.parseInt(searchParams.get("page") || "1")

  useEffect(() => {
    // In a real app, this would fetch from your PHP backend with filters
    // Example: fetch(`/api/products?category=${category}&minPrice=${minPrice}&maxPrice=${maxPrice}&sort=${sort}&page=${page}`)
    setLoading(true)

    setTimeout(() => {
      // Generate product images with different colors
      const colors = ["blue", "red", "green", "purple", "orange", "teal"]
      const categories = ["Clothing", "Electronics", "Accessories", "Footwear"]

      const mockProducts = Array.from({ length: 12 }, (_, i) => {
        const productId = i + 1
        const categoryIndex = Math.floor(Math.random() * 4)
        const colorIndex = Math.floor(Math.random() * colors.length)

        return {
          id: productId,
          name: `${categories[categoryIndex]} Item ${productId}`,
          price: Math.floor(Math.random() * 200) + 20,
          image: `/placeholder.svg?height=300&width=300&text=${colors[colorIndex]}`,
          category: categories[categoryIndex],
          discount: Math.random() > 0.7 ? Math.floor(Math.random() * 30) + 5 : undefined,
          rating: Math.floor(Math.random() * 5) + 1,
          reviews: Math.floor(Math.random() * 100) + 1,
        }
      })

      setProducts(mockProducts)
      setTotalProducts(60)
      setCurrentPage(page)
      setTotalPages(5)
      setLoading(false)
    }, 800)
  }, [category, minPrice, maxPrice, sort, page])

  // Update URL with filters
  const updateFilters = (filters: Record<string, string>) => {
    const params = new URLSearchParams(searchParams.toString())

    Object.entries(filters).forEach(([key, value]) => {
      if (value) {
        params.set(key, value)
      } else {
        params.delete(key)
      }
    })

    // Reset to page 1 when filters change
    params.set("page", "1")

    router.push(`/products?${params.toString()}`)
  }

  const handlePageChange = (page: number) => {
    const params = new URLSearchParams(searchParams.toString())
    params.set("page", page.toString())
    router.push(`/products?${params.toString()}`)
  }

  const clearAllFilters = () => {
    router.push("/products")
  }

  const toggleFilters = () => {
    setFiltersOpen(!filtersOpen)
  }

  // Always show filters on desktop
  useEffect(() => {
    if (isDesktop) {
      setFiltersOpen(true)
    } else {
      setFiltersOpen(false)
    }
  }, [isDesktop])

  return (
    <div className="mt-6">
      <div className="flex flex-col lg:flex-row gap-8">
        {/* Mobile filter toggle */}
        <div className="lg:hidden flex justify-between items-center mb-4">
          <Button variant="outline" size="sm" onClick={toggleFilters} className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            Filters
          </Button>

          <ProductsSort currentSort={sort} onSortChange={(value) => updateFilters({ sort: value })} />
        </div>

        {/* Filters sidebar */}
        {filtersOpen && (
          <div className="lg:w-64 space-y-6">
            <div className="flex items-center justify-between lg:hidden">
              <h3 className="font-semibold">Filters</h3>
              <Button variant="ghost" size="sm" onClick={toggleFilters}>
                <X className="h-4 w-4" />
              </Button>
            </div>

            <ProductFilters
              selectedCategory={category}
              priceRange={[minPrice ? Number.parseInt(minPrice) : 0, maxPrice ? Number.parseInt(maxPrice) : 500]}
              onCategoryChange={(value) => updateFilters({ category: value })}
              onPriceChange={(min, max) => updateFilters({ minPrice: min.toString(), maxPrice: max.toString() })}
              onClearFilters={clearAllFilters}
            />
          </div>
        )}

        {/* Products grid */}
        <div className="flex-1">
          <div className="hidden lg:flex justify-between items-center mb-6">
            <div>
              <p className="text-sm text-muted-foreground">
                Showing <span className="font-medium text-foreground">{products.length}</span> of{" "}
                <span className="font-medium text-foreground">{totalProducts}</span> products
              </p>
            </div>

            <ProductsSort currentSort={sort} onSortChange={(value) => updateFilters({ sort: value })} />
          </div>

          {loading ? (
            <ProductGrid.Skeleton />
          ) : (
            <>
              <ProductGrid products={products} />

              <div className="mt-8 flex justify-center">
                <ProductsPagination currentPage={currentPage} totalPages={totalPages} onPageChange={handlePageChange} />
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  )
}

