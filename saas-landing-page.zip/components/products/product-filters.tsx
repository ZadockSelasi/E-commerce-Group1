"use client"

import { useState } from "react"
import Image from "next/image"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { X } from "lucide-react"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

const categories = [
  {
    id: "clothing",
    label: "Clothing",
    image: "/placeholder.svg?height=60&width=60",
  },
  {
    id: "electronics",
    label: "Electronics",
    image: "/placeholder.svg?height=60&width=60",
  },
  {
    id: "accessories",
    label: "Accessories",
    image: "/placeholder.svg?height=60&width=60",
  },
  {
    id: "footwear",
    label: "Footwear",
    image: "/placeholder.svg?height=60&width=60",
  },
]

interface ProductFiltersProps {
  selectedCategory: string
  priceRange: [number, number]
  onCategoryChange: (category: string) => void
  onPriceChange: (min: number, max: number) => void
  onClearFilters: () => void
}

export default function ProductFilters({
  selectedCategory,
  priceRange,
  onCategoryChange,
  onPriceChange,
  onClearFilters,
}: ProductFiltersProps) {
  const [localPriceRange, setLocalPriceRange] = useState<[number, number]>(priceRange)

  const handlePriceChange = (value: number[]) => {
    setLocalPriceRange([value[0], value[1]])
  }

  const applyPriceRange = () => {
    onPriceChange(localPriceRange[0], localPriceRange[1])
  }

  const hasActiveFilters = selectedCategory || priceRange[0] > 0 || priceRange[1] < 500

  return (
    <div className="space-y-6">
      {hasActiveFilters && (
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-medium">Active Filters</h3>
            <Button variant="ghost" size="sm" onClick={onClearFilters} className="h-8 px-2 text-xs">
              Clear all
            </Button>
          </div>
          <div className="flex flex-wrap gap-2">
            {selectedCategory && (
              <Badge variant="secondary" className="flex items-center gap-1">
                {categories.find((c) => c.id === selectedCategory)?.label}
                <Button variant="ghost" size="icon" className="h-4 w-4 p-0 ml-1" onClick={() => onCategoryChange("")}>
                  <X className="h-3 w-3" />
                  <span className="sr-only">Remove</span>
                </Button>
              </Badge>
            )}
            {(priceRange[0] > 0 || priceRange[1] < 500) && (
              <Badge variant="secondary" className="flex items-center gap-1">
                ${priceRange[0]} - ${priceRange[1]}
                <Button variant="ghost" size="icon" className="h-4 w-4 p-0 ml-1" onClick={() => onPriceChange(0, 500)}>
                  <X className="h-3 w-3" />
                  <span className="sr-only">Remove</span>
                </Button>
              </Badge>
            )}
          </div>
        </div>
      )}

      <Accordion type="multiple" defaultValue={["categories", "price"]}>
        <AccordionItem value="categories">
          <AccordionTrigger>Categories</AccordionTrigger>
          <AccordionContent>
            <div className="grid grid-cols-1 gap-3 pt-1">
              {categories.map((category) => (
                <div
                  key={category.id}
                  className={`flex items-center space-x-3 p-2 rounded-lg cursor-pointer transition-colors ${
                    selectedCategory === category.id
                      ? "bg-primary/10 border border-primary/30"
                      : "hover:bg-muted border border-transparent"
                  }`}
                  onClick={() => onCategoryChange(selectedCategory === category.id ? "" : category.id)}
                >
                  <div className="relative w-12 h-12 rounded-md overflow-hidden border">
                    <Image
                      src={category.image || "/placeholder.svg"}
                      alt={category.label}
                      fill
                      className="object-cover"
                    />
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium">{category.label}</p>
                  </div>
                  <Checkbox checked={selectedCategory === category.id} className="pointer-events-none" />
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="price">
          <AccordionTrigger>Price Range</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-4 pt-2">
              <Slider
                min={0}
                max={500}
                step={10}
                value={[localPriceRange[0], localPriceRange[1]]}
                onValueChange={handlePriceChange}
                className="my-6"
              />
              <div className="flex items-center justify-between">
                <span className="text-sm">${localPriceRange[0]}</span>
                <span className="text-sm">${localPriceRange[1]}</span>
              </div>
              <Button size="sm" onClick={applyPriceRange} className="w-full">
                Apply
              </Button>
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="ratings">
          <AccordionTrigger>Ratings</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2 pt-1">
              {[5, 4, 3, 2, 1].map((rating) => (
                <div key={rating} className="flex items-center space-x-2">
                  <Checkbox id={`rating-${rating}`} />
                  <label
                    htmlFor={`rating-${rating}`}
                    className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 flex items-center"
                  >
                    <div className="flex">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <svg
                          key={i}
                          className={`h-4 w-4 ${i < rating ? "text-yellow-400 fill-yellow-400" : "text-gray-300"}`}
                          xmlns="http://www.w3.org/2000/svg"
                          viewBox="0 0 24 24"
                        >
                          <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
                        </svg>
                      ))}
                    </div>
                    <span className="ml-1">& Up</span>
                  </label>
                </div>
              ))}
            </div>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="availability">
          <AccordionTrigger>Availability</AccordionTrigger>
          <AccordionContent>
            <div className="space-y-2 pt-1">
              <div className="flex items-center space-x-2">
                <Checkbox id="in-stock" />
                <label
                  htmlFor="in-stock"
                  className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  In Stock
                </label>
              </div>
              <div className="flex items-center space-x-2">
                <Checkbox id="out-of-stock" />
                <label
                  htmlFor="out-of-stock"
                  className="text-sm leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  Out of Stock
                </label>
              </div>
            </div>
          </AccordionContent>
        </AccordionItem>
      </Accordion>

      {/* Featured Products */}
      <div className="mt-6 pt-6 border-t">
        <h3 className="text-sm font-medium mb-4">Featured Products</h3>
        <div className="space-y-4">
          {[1, 2].map((item) => (
            <div key={item} className="flex items-start space-x-3">
              <div className="relative w-16 h-16 rounded-md overflow-hidden border">
                <Image
                  src={`/placeholder.svg?height=64&width=64&text=Product${item}`}
                  alt={`Featured Product ${item}`}
                  fill
                  className="object-cover"
                />
              </div>
              <div>
                <h4 className="text-sm font-medium">Featured Product {item}</h4>
                <p className="text-sm text-muted-foreground">$99.99</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

