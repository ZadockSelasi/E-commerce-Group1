"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { Plus, Edit, Trash2, Check, MapPin, Home, Briefcase } from "lucide-react"

interface Address {
  id: string
  name: string
  line1: string
  line2?: string
  city: string
  state: string
  postalCode: string
  country: string
  type: "home" | "work" | "other"
  isDefault: boolean
}

export default function AccountAddresses() {
  const { toast } = useToast()
  const [addresses, setAddresses] = useState<Address[]>([
    {
      id: "addr1",
      name: "Home Address",
      line1: "123 Main Street",
      line2: "Apt 4B",
      city: "New York",
      state: "NY",
      postalCode: "10001",
      country: "United States",
      type: "home",
      isDefault: true,
    },
    {
      id: "addr2",
      name: "Work Address",
      line1: "456 Business Ave",
      city: "New York",
      state: "NY",
      postalCode: "10002",
      country: "United States",
      type: "work",
      isDefault: false,
    },
  ])

  const handleSetDefault = (id: string) => {
    setAddresses(
      addresses.map((address) => ({
        ...address,
        isDefault: address.id === id,
      })),
    )

    toast({
      title: "Default address updated",
      description: "Your default shipping address has been updated.",
    })
  }

  const handleDelete = (id: string) => {
    setAddresses(addresses.filter((address) => address.id !== id))

    toast({
      title: "Address removed",
      description: "The address has been removed from your account.",
    })
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold">Your Addresses</h2>
        <Button className="flex items-center gap-2">
          <Plus className="h-4 w-4" />
          <span>Add New Address</span>
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {addresses.map((address) => (
          <Card key={address.id} className={address.isDefault ? "border-primary" : ""}>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {address.type === "home" ? (
                    <Home className="h-4 w-4 text-muted-foreground" />
                  ) : address.type === "work" ? (
                    <Briefcase className="h-4 w-4 text-muted-foreground" />
                  ) : (
                    <MapPin className="h-4 w-4 text-muted-foreground" />
                  )}
                  <CardTitle className="text-lg">{address.name}</CardTitle>
                </div>
                {address.isDefault && (
                  <div className="bg-primary/10 text-primary rounded-full px-2 py-1 text-xs font-medium">Default</div>
                )}
              </div>
              <CardDescription>{address.type.charAt(0).toUpperCase() + address.type.slice(1)} Address</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-sm space-y-1">
                <p>{address.line1}</p>
                {address.line2 && <p>{address.line2}</p>}
                <p>
                  {address.city}, {address.state} {address.postalCode}
                </p>
                <p>{address.country}</p>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between pt-2">
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="h-8">
                  <Edit className="h-3.5 w-3.5 mr-1" />
                  Edit
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="h-8 text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/20"
                  onClick={() => handleDelete(address.id)}
                >
                  <Trash2 className="h-3.5 w-3.5 mr-1" />
                  Remove
                </Button>
              </div>
              {!address.isDefault && (
                <Button variant="ghost" size="sm" className="h-8" onClick={() => handleSetDefault(address.id)}>
                  <Check className="h-3.5 w-3.5 mr-1" />
                  Set as Default
                </Button>
              )}
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}

