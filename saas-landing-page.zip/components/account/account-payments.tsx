"use client"

import { useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { Plus, Edit, Trash2, Check } from "lucide-react"

interface PaymentMethod {
  id: string
  type: "visa" | "mastercard" | "amex" | "paypal"
  name: string
  last4: string
  expiry?: string
  isDefault: boolean
}

export default function AccountPayments() {
  const { toast } = useToast()
  const [paymentMethods, setPaymentMethods] = useState<PaymentMethod[]>([
    {
      id: "card1",
      type: "visa",
      name: "John Doe",
      last4: "4242",
      expiry: "12/25",
      isDefault: true,
    },
    {
      id: "card2",
      type: "mastercard",
      name: "John Doe",
      last4: "5555",
      expiry: "10/24",
      isDefault: false,
    },
    {
      id: "paypal1",
      type: "paypal",
      name: "john.doe@example.com",
      last4: "",
      isDefault: false,
    },
  ])

  const handleSetDefault = (id: string) => {
    setPaymentMethods(
      paymentMethods.map((method) => ({
        ...method,
        isDefault: method.id === id,
      })),
    )

    toast({
      title: "Default payment method updated",
      description: "Your default payment method has been updated.",
    })
  }

  const handleDelete = (id: string) => {
    setPaymentMethods(paymentMethods.filter((method) => method.id !== id))

    toast({
      title: "Payment method removed",
      description: "The payment method has been removed from your account.",
    })
  }

  const getCardImage = (type: string) => {
    switch (type) {
      case "visa":
        return "/images/visa-card.png"
      case "mastercard":
        return "/images/mastercard.png"
      case "amex":
        return "/images/amex-card.png"
      case "paypal":
        return "/images/paypal-logo.png"
      default:
        return "/images/generic-card.png"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold">Payment Methods</h2>
        <Button className="flex items-center gap-2">
          <Plus className="h-4 w-4" />
          <span>Add Payment Method</span>
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {paymentMethods.map((method) => (
          <Card key={method.id} className={method.isDefault ? "border-primary" : ""}>
            <CardHeader className="pb-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="relative w-10 h-6">
                    <Image
                      src={getCardImage(method.type) || "/placeholder.svg"}
                      alt={method.type}
                      fill
                      className="object-contain"
                    />
                  </div>
                  <CardTitle className="text-lg">
                    {method.type === "paypal"
                      ? "PayPal"
                      : `${method.type.charAt(0).toUpperCase() + method.type.slice(1)} ending in ${method.last4}`}
                  </CardTitle>
                </div>
                {method.isDefault && (
                  <div className="bg-primary/10 text-primary rounded-full px-2 py-1 text-xs font-medium">Default</div>
                )}
              </div>
              <CardDescription>{method.type === "paypal" ? method.name : `Expires ${method.expiry}`}</CardDescription>
            </CardHeader>
            <CardFooter className="flex justify-between pt-2">
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="h-8">
                  <Edit className="h-3.5 w-3.5 mr-1" />
                  Edit
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  className="h-8 text-red-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/20"
                  onClick={() => handleDelete(method.id)}
                >
                  <Trash2 className="h-3.5 w-3.5 mr-1" />
                  Remove
                </Button>
              </div>
              {!method.isDefault && (
                <Button variant="ghost" size="sm" className="h-8" onClick={() => handleSetDefault(method.id)}>
                  <Check className="h-3.5 w-3.5 mr-1" />
                  Set as Default
                </Button>
              )}
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  )
}

