"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Label } from "@/components/ui/label"
import { useToast } from "@/components/ui/use-toast"
import { Loader2 } from "lucide-react"

export default function AccountSettings() {
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [settings, setSettings] = useState({
    emailNotifications: true,
    orderUpdates: true,
    promotions: true,
    newProducts: false,
    newsletter: true,
    twoFactorAuth: false,
    activityLog: true,
    darkMode: false,
  })

  const handleToggle = (setting: keyof typeof settings) => {
    setSettings((prev) => ({
      ...prev,
      [setting]: !prev[setting],
    }))
  }

  const handleSave = async () => {
    setIsLoading(true)

    // In a real app, this would call your PHP backend
    // Example: await fetch('/api/account/settings', { method: 'PUT', body: JSON.stringify(settings) })

    setTimeout(() => {
      toast({
        title: "Settings updated",
        description: "Your account settings have been updated successfully.",
      })
      setIsLoading(false)
    }, 1500)
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Notification Preferences</CardTitle>
          <CardDescription>Manage how and when you receive notifications from us</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="emailNotifications">Email Notifications</Label>
              <p className="text-sm text-muted-foreground">Receive emails about your account activity</p>
            </div>
            <Switch
              id="emailNotifications"
              checked={settings.emailNotifications}
              onCheckedChange={() => handleToggle("emailNotifications")}
            />
          </div>
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="orderUpdates">Order Updates</Label>
              <p className="text-sm text-muted-foreground">Receive notifications about your order status</p>
            </div>
            <Switch
              id="orderUpdates"
              checked={settings.orderUpdates}
              onCheckedChange={() => handleToggle("orderUpdates")}
            />
          </div>
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="promotions">Promotions & Discounts</Label>
              <p className="text-sm text-muted-foreground">Receive notifications about sales and special offers</p>
            </div>
            <Switch id="promotions" checked={settings.promotions} onCheckedChange={() => handleToggle("promotions")} />
          </div>
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="newProducts">New Products</Label>
              <p className="text-sm text-muted-foreground">Be the first to know about new product launches</p>
            </div>
            <Switch
              id="newProducts"
              checked={settings.newProducts}
              onCheckedChange={() => handleToggle("newProducts")}
            />
          </div>
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="newsletter">Weekly Newsletter</Label>
              <p className="text-sm text-muted-foreground">Receive our weekly newsletter with tips and trends</p>
            </div>
            <Switch id="newsletter" checked={settings.newsletter} onCheckedChange={() => handleToggle("newsletter")} />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Security Settings</CardTitle>
          <CardDescription>Manage your account security preferences</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="twoFactorAuth">Two-Factor Authentication</Label>
              <p className="text-sm text-muted-foreground">Add an extra layer of security to your account</p>
            </div>
            <Switch
              id="twoFactorAuth"
              checked={settings.twoFactorAuth}
              onCheckedChange={() => handleToggle("twoFactorAuth")}
            />
          </div>
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="activityLog">Activity Log</Label>
              <p className="text-sm text-muted-foreground">Keep track of all activities on your account</p>
            </div>
            <Switch
              id="activityLog"
              checked={settings.activityLog}
              onCheckedChange={() => handleToggle("activityLog")}
            />
          </div>
        </CardContent>
        <CardFooter className="flex justify-end">
          <Button onClick={handleSave} disabled={isLoading}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Saving...
              </>
            ) : (
              "Save Changes"
            )}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

