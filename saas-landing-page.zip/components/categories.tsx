import Link from "next/link"
import Image from "next/image"
import { Card } from "@/components/ui/card"

const categories = [
  {
    id: 1,
    name: "Clothing",
    image: "/placeholder.svg?height=200&width=200",
    count: 120,
  },
  {
    id: 2,
    name: "Electronics",
    image: "/placeholder.svg?height=200&width=200",
    count: 85,
  },
  {
    id: 3,
    name: "Accessories",
    image: "/placeholder.svg?height=200&width=200",
    count: 64,
  },
  {
    id: 4,
    name: "Footwear",
    image: "/placeholder.svg?height=200&width=200",
    count: 47,
  },
]

export function Categories() {
  return (
    <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4 mt-10">
      {categories.map((category) => (
        <Link key={category.id} href={`/categories/${category.id}`}>
          <Card className="overflow-hidden hover:shadow-lg transition-shadow">
            <div className="relative h-40">
              <Image src={category.image || "/placeholder.svg"} alt={category.name} fill className="object-cover" />
              <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                <div className="text-center text-white">
                  <h3 className="text-xl font-bold">{category.name}</h3>
                  <p className="text-sm">{category.count} Products</p>
                </div>
              </div>
            </div>
          </Card>
        </Link>
      ))}
    </div>
  )
}

