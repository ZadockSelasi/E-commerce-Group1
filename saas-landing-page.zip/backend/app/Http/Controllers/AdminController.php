<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Product;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class AdminController extends Controller
{
    /**
     * Dashboard statistics
     */
    public function dashboard()
    {
        // Check admin permissions
        if (!auth()->user()->isAdmin()) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }
        
        // Get total sales
        $totalSales = Order::where('status', '!=', 'cancelled')->sum('total');
        
        // Get total orders
        $totalOrders = Order::count();
        
        // Get total products
        $totalProducts = Product::count();
        
        // Get total users
        $totalUsers = User::count();
        
        // Get recent orders
        $recentOrders = Order::with('user')
            ->orderBy('created_at', 'desc')
            ->take(5)
            ->get();
        
        // Get sales by month (last 6 months)
        $salesByMonth = DB::table('orders')
            ->select(DB::raw('MONTH(created_at) as month, YEAR(created_at) as year, SUM(total) as total'))
            ->where('status', '!=', 'cancelled')
            ->whereRaw('created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)')
            ->groupBy('year', 'month')
            ->orderBy('year', 'desc')
            ->orderBy('month', 'desc')
            ->get();
        
        // Get top selling products
        $topProducts = DB::table('order_items')
            ->join('products', 'order_items.product_id', '=', 'products.id')
            ->select('products.id', 'products.name', DB::raw('SUM(order_items.quantity) as total_quantity'))
            ->groupBy('products.id', 'products.name')
            ->orderBy('total_quantity', 'desc')
            ->take(5)
            ->get();
        
        return response()->json([
            'total_sales' => $totalSales,
            'total_orders' => $totalOrders,
            'total_products' => $totalProducts,
            'total_users' => $totalUsers,
            'recent_orders' => $recentOrders,
            'sales_by_month' => $salesByMonth,
            'top_products' => $topProducts
        ]);
    }
    
    /**
     * Get all orders (admin only)
     */
    public function orders(Request $request)
    {
        // Check admin permissions
        if (!auth()->user()->isAdmin()) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }
        
        $query = Order::with('user');
        
        // Filter by status
        if ($request->has('status')) {
            $query->where('status', $request->status);
        }
        
        // Filter by date range
        if ($request->has('start_date')) {
            $query->whereDate('created_at', '>=', $request->start_date);
        }
        if ($request->has('end_date')) {
            $query->whereDate('created_at', '<=', $request->end_date);
        }
        
        // Sort orders
        if ($request->has('sort_by')) {
            $sortField = $request->sort_by;
            $sortDirection = $request->has('sort_direction') ? $request->sort_direction : 'desc';
            $query->orderBy($sortField, $sortDirection);
        } else {
            $query->orderBy('created_at', 'desc');
        }
        
        // Paginate results
        $perPage = $request->has('per_page') ? $request->per_page : 15;
        $orders = $query->paginate($perPage);
        
        return response()->json($orders);
    }
    
    /**
     * Get all users (admin only)
     */
    public function users(Request $request)
    {
        // Check admin permissions
        if (!auth()->user()->isAdmin()) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }
        
        $query = User::query();
        
        // Search by name or email
        if ($request->has('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%");
            });
        }
        
        // Sort users
        if ($request->has('sort_by')) {
            $sortField = $request->sort_by;
            $sortDirection = $request->has('sort_direction') ? $request->sort_direction : 'asc';
            $query->orderBy($sortField, $sortDirection);
        } else {
            $query->orderBy('created_at', 'desc');
        }
        
        // Paginate results
        $perPage = $request->has('per_page') ? $request->per_page : 15;
        $users = $query->paginate($perPage);
        
        return response()->json($users);
    }
}

