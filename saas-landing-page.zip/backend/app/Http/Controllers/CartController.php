<?php

namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\CartItem;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class CartController extends Controller
{
    /**
     * Get the user's cart
     */
    public function index(Request $request)
    {
        $cart = $this->getCart($request);
        
        return response()->json([
            'cart' => $cart,
            'items' => $cart->items()->with('product')->get()
        ]);
    }

    /**
     * Add item to cart
     */
    public function addItem(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'product_id' => 'required|exists:products,id',
            'quantity' => 'required|integer|min:1',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $cart = $this->getCart($request);
        $product = Product::findOrFail($request->product_id);

        // Check if product is in stock
        if ($product->stock < $request->quantity) {
            return response()->json([
                'message' => 'Not enough stock available'
            ], 400);
        }

        // Check if item already exists in cart
        $cartItem = CartItem::where('cart_id', $cart->id)
            ->where('product_id', $request->product_id)
            ->first();

        if ($cartItem) {
            // Update quantity if item exists
            $cartItem->quantity += $request->quantity;
            $cartItem->save();
        } else {
            // Create new cart item
            $cartItem = new CartItem();
            $cartItem->cart_id = $cart->id;
            $cartItem->product_id = $request->product_id;
            $cartItem->quantity = $request->quantity;
            $cartItem->price = $product->price;
            $cartItem->save();
        }

        return response()->json([
            'message' => 'Item added to cart',
            'cart' => $cart,
            'items' => $cart->items()->with('product')->get()
        ]);
    }

    /**
     * Update cart item quantity
     */
    public function updateItem(Request $request, $itemId)
    {
        $validator = Validator::make($request->all(), [
            'quantity' => 'required|integer|min:1',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        $cart = $this->getCart($request);
        $cartItem = CartItem::where('cart_id', $cart->id)
            ->where('id', $itemId)
            ->firstOrFail();

        $product = Product::findOrFail($cartItem->product_id);

        // Check if product is in stock
        if ($product->stock < $request->quantity) {
            return response()->json([
                'message' => 'Not enough stock available'
            ], 400);
        }

        $cartItem->quantity = $request->quantity;
        $cartItem->save();

        return response()->json([
            'message' => 'Cart item updated',
            'cart' => $cart,
            'items' => $cart->items()->with('product')->get()
        ]);
    }

    /**
     * Remove item from cart
     */
    public function removeItem(Request $request, $itemId)
    {
        $cart = $this->getCart($request);
        $cartItem = CartItem::where('cart_id', $cart->id)
            ->where('id', $itemId)
            ->firstOrFail();

        $cartItem->delete();

        return response()->json([
            'message' => 'Item removed from cart',
            'cart' => $cart,
            'items' => $cart->items()->with('product')->get()
        ]);
    }

    /**
     * Clear cart
     */
    public function clear(Request $request)
    {
        $cart = $this->getCart($request);
        CartItem::where('cart_id', $cart->id)->delete();

        return response()->json([
            'message' => 'Cart cleared',
            'cart' => $cart,
            'items' => []
        ]);
    }

    /**
     * Apply coupon to cart
     */
    public function applyCoupon(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'code' => 'required|string',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        // In a real app, you would validate the coupon code against a database
        // For this example, we'll just accept any code
        $cart = $this->getCart($request);
        $cart->coupon_code = $request->code;
        $cart->discount = 10.00; // Example discount amount
        $cart->save();

        return response()->json([
            'message' => 'Coupon applied',
            'cart' => $cart,
            'items' => $cart->items()->with('product')->get()
        ]);
    }

    /**
     * Get or create a cart for the current session/user
     */
    private function getCart(Request $request)
    {
        if (auth()->check()) {
            // Logged in user - get or create their cart
            $cart = Cart::firstOrCreate(
                ['user_id' => auth()->id()],
                ['session_id' => $request->session()->getId()]
            );
        } else {
            // Guest user - get or create cart based on session
            $sessionId = $request->session()->getId();
            $cart = Cart::firstOrCreate(
                ['session_id' => $sessionId, 'user_id' => null],
                []
            );
        }

        return $cart;
    }
}

