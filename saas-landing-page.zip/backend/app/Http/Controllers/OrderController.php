<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class OrderController extends Controller
{
    /**
     * Display a listing of the user's orders.
     */
    public function index()
    {
        $orders = Order::where('user_id', auth()->id())
            ->orderBy('created_at', 'desc')
            ->paginate(10);

        return response()->json($orders);
    }

    /**
     * Store a newly created order.
     */
    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'shipping_address' => 'required|string',
            'shipping_city' => 'required|string',
            'shipping_state' => 'required|string',
            'shipping_postal_code' => 'required|string',
              => 'required|string',
            'shipping_postal_code' => 'required|string',
            'shipping_country' => 'required|string',
            'payment_method' => 'required|string|in:credit_card,paypal,bank_transfer',
            'cart_items' => 'required|array',
            'cart_items.*.product_id' => 'required|exists:products,id',
            'cart_items.*.quantity' => 'required|integer|min:1',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        // Start a database transaction
        \DB::beginTransaction();

        try {
            // Create the order
            $order = new Order();
            $order->user_id = auth()->id();
            $order->order_number = 'ORD-' . strtoupper(Str::random(10));
            $order->status = 'pending';
            $order->shipping_address = $request->shipping_address;
            $order->shipping_city = $request->shipping_city;
            $order->shipping_state = $request->shipping_state;
            $order->shipping_postal_code = $request->shipping_postal_code;
            $order->shipping_country = $request->shipping_country;
            $order->payment_method = $request->payment_method;
            
            $subtotal = 0;
            $tax = 0;
            $shipping = 10.00; // Fixed shipping cost for this example
            
            // Process each cart item
            foreach ($request->cart_items as $item) {
                $product = Product::findOrFail($item['product_id']);
                
                // Check if product is in stock
                if ($product->stock < $item['quantity']) {
                    \DB::rollBack();
                    return response()->json([
                        'message' => "Not enough stock available for {$product->name}"
                    ], 400);
                }
                
                // Calculate item total
                $itemTotal = $product->price * $item['quantity'];
                $subtotal += $itemTotal;
                
                // Reduce product stock
                $product->stock -= $item['quantity'];
                $product->save();
                
                // Create order item
                $orderItem = new OrderItem();
                $orderItem->product_id = $product->id;
                $orderItem->quantity = $item['quantity'];
                $orderItem->price = $product->price;
                $orderItem->total = $itemTotal;
                
                // Add to order items (will be saved after order is created)
                $order->items[] = $orderItem;
            }
            
            // Calculate tax (example: 10%)
            $tax = $subtotal * 0.10;
            
            // Set order totals
            $order->subtotal = $subtotal;
            $order->tax = $tax;
            $order->shipping = $shipping;
            $order->total = $subtotal + $tax + $shipping;
            
            // Save the order
            $order->save();
            
            // Save order items
            foreach ($order->items as $item) {
                $item->order_id = $order->id;
                $item->save();
            }
            
            // Process payment (mock implementation)
            $paymentSuccess = $this->processPayment($order, $request->payment_method);
            
            if (!$paymentSuccess) {
                \DB::rollBack();
                return response()->json([
                    'message' => 'Payment processing failed'
                ], 400);
            }
            
            // Clear the user's cart
            if (auth()->check()) {
                $cart = \App\Models\Cart::where('user_id', auth()->id())->first();
                if ($cart) {
                    \App\Models\CartItem::where('cart_id', $cart->id)->delete();
                }
            }
            
            // Commit the transaction
            \DB::commit();
            
            return response()->json([
                'message' => 'Order placed successfully',
                'order' => $order
            ], 201);
            
        } catch (\Exception $e) {
            \DB::rollBack();
            return response()->json([
                'message' => 'An error occurred while processing your order',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Display the specified order.
     */
    public function show($id)
    {
        $order = Order::with('items.product')->findOrFail($id);
        
        // Check if the order belongs to the authenticated user
        if ($order->user_id !== auth()->id() && !auth()->user()->isAdmin()) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }
        
        return response()->json($order);
    }

    /**
     * Update the order status (admin only).
     */
    public function updateStatus(Request $request, $id)
    {
        // Check admin permissions
        if (!auth()->user()->isAdmin()) {
            return response()->json(['message' => 'Unauthorized'], 403);
        }
        
        $validator = Validator::make($request->all(), [
            'status' => 'required|string|in:pending,processing,shipped,delivered,cancelled',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }
        
        $order = Order::findOrFail($id);
        $order->status = $request->status;
        $order->save();
        
        return response()->json([
            'message' => 'Order status updated',
            'order' => $order
        ]);
    }

    /**
     * Process payment (mock implementation)
     */
    private function processPayment($order, $paymentMethod)
    {
        // In a real application, this would integrate with a payment gateway
        // For this example, we'll just return true to simulate successful payment
        return true;
    }
}

